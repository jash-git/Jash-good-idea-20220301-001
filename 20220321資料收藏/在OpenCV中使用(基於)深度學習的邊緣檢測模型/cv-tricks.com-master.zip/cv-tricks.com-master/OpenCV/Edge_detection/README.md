##To Download the pretrained model:
sh download_pretrained.sh

##To Run edge detection on a new image:
python edge.py --input image.jpg 
