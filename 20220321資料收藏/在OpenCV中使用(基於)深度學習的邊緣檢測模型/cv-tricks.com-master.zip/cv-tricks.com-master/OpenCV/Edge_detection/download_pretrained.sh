wget http://vcl.ucsd.edu/hed/hed_pretrained_bsds.caffemodel
