To Run this code:

1. Download the yolov2 weights from here: 

https://drive.google.com/file/d/1obd4-7NH-G_ixTwga4HKkpnP78gBcZ9n/view?usp=sharing

2. Now run using the following command:

python3 predict_on_yolo.py --input test.jpg

