### You should have TensorFlow installed in your system.
### Please download the model weights from this location and put them in the data folder: 

https://drive.google.com/open?id=11Nni-IM0acRrrhQ4bmG5_uxj-RLA2NCm

### To run the model execute the following command.

python classify_nsfw.py -m ./data/open_nsfw-weights.npy ./test_images/test_1.jpeg
