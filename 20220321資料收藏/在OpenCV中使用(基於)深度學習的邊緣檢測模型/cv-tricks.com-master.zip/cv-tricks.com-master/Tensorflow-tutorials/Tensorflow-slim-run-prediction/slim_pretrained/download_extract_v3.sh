wget http://download.tensorflow.org/models/inception_v3_2016_08_28.tar.gz
tar -zxvf inception_v3_2016_08_28.tar.gz
