wget  	https://s3-ap-southeast-1.amazonaws.com/aimonk/cv-tricks.com/tutorials/FrozenGraph_Sept18/checkpoint
wget  	https://s3-ap-southeast-1.amazonaws.com/aimonk/cv-tricks.com/tutorials/FrozenGraph_Sept18/dogs-cats-model.data-00000-of-00001
wget  	https://s3-ap-southeast-1.amazonaws.com/aimonk/cv-tricks.com/tutorials/FrozenGraph_Sept18/dogs-cats-model.index
wget  	https://s3-ap-southeast-1.amazonaws.com/aimonk/cv-tricks.com/tutorials/FrozenGraph_Sept18/dogs-cats-model.meta
