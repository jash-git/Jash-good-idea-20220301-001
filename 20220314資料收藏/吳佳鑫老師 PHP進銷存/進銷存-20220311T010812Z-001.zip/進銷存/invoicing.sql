-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1:3306
-- 產生時間： 
-- 伺服器版本： 8.0.18
-- PHP 版本： 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `invoicing`
--

-- --------------------------------------------------------

--
-- 資料表結構 `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `m_num` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_num` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_pname` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_title` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_addr` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_mail` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_pcode` int(6) NOT NULL,
  `c_tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_memo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`c_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `customer`
--

INSERT INTO `customer` (`m_num`, `c_num`, `c_username`, `c_pname`, `c_title`, `c_addr`, `c_mail`, `c_pcode`, `c_tel`, `c_phone`, `c_memo`) VALUES
('20210901065241', '20211001054652', '中華職訓', 'XXX', '000000', '台中市復興路4段', '20210522.cc@gmail.com', 40144, '042000000', '0921000000', '<p>1</p>\r\n\r\n<p>&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- 資料表結構 `memberx`
--

DROP TABLE IF EXISTS `memberx`;
CREATE TABLE IF NOT EXISTS `memberx` (
  `m_id` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_pwd` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_num` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_adr` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_mail` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_pname` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_jointime` datetime NOT NULL,
  `m_logintime` datetime NOT NULL,
  `m_login` int(4) NOT NULL,
  `m_power` int(1) NOT NULL,
  PRIMARY KEY (`m_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `memberx`
--

INSERT INTO `memberx` (`m_id`, `m_pwd`, `m_username`, `m_num`, `m_tel`, `m_phone`, `m_adr`, `m_mail`, `m_pname`, `m_jointime`, `m_logintime`, `m_login`, `m_power`) VALUES
('12', '1234', 'XXX公司', '20210901065241', '44444444444', '55', '66', '20210210.cc@gmail.com', '88', '2021-09-30 07:29:34', '2021-10-07 11:39:53', 22, 1),
('1', '1', 'OOO公司', '20211001061918', '1', '1', '1', '', 'Joy', '2021-10-06 14:19:27', '2021-10-07 11:35:36', 2, 0);

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `m_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `p_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ps_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `p_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `p_cost` int(10) NOT NULL,
  `p_price` int(10) NOT NULL,
  `p_stock` int(10) NOT NULL,
  `p_memo` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`p_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `product`
--

INSERT INTO `product` (`m_num`, `p_num`, `s_num`, `ps_num`, `p_name`, `p_cost`, `p_price`, `p_stock`, `p_memo`) VALUES
('20210901065241', '20211001075539', '20211001033310', '1', 'OOO', 1000, 2000, 12, '<p>1</p>\r\n'),
('20210901065241', '20211001083309', '20211001080101', '2', '2', 2, 13, 30, '<p>1</p>\r\n');

-- --------------------------------------------------------

--
-- 資料表結構 `purchase`
--

DROP TABLE IF EXISTS `purchase`;
CREATE TABLE IF NOT EXISTS `purchase` (
  `m_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pu_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pu_snum` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pu_idate` datetime NOT NULL,
  `pu_date` datetime NOT NULL,
  `pu_redate` datetime NOT NULL,
  `pu_memo` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pu_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `purchase`
--

INSERT INTO `purchase` (`m_num`, `pu_num`, `pu_snum`, `pu_idate`, `pu_date`, `pu_redate`, `pu_memo`) VALUES
('20210901065241', '20211001060650', '20211004-02', '2021-10-04 16:25:29', '2021-10-04 00:00:00', '2021-10-04 08:07:52', '<p>440+150</p>\r\n\r\n<p>88888</p>\r\n'),
('20210901065241', '20211001054546', '12345', '0000-00-00 00:00:00', '2021-10-07 05:46:13', '2021-10-07 06:27:43', '<p>123</p>\r\n');

-- --------------------------------------------------------

--
-- 資料表結構 `purchase_product`
--

DROP TABLE IF EXISTS `purchase_product`;
CREATE TABLE IF NOT EXISTS `purchase_product` (
  `pp_id` int(11) NOT NULL AUTO_INCREMENT,
  `pu_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ps_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pu_quantity` int(10) NOT NULL,
  `p_cost` int(10) NOT NULL,
  `s_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `purchase_product`
--

INSERT INTO `purchase_product` (`pp_id`, `pu_num`, `ps_num`, `pu_quantity`, `p_cost`, `s_num`) VALUES
(15, '20211001054546', '20211001083309', 4, 2, '20211001080101'),
(3, '20211001060650', '20211001075539', 5, 60, '20211001033310'),
(4, '20211001060650', '20211001083309', 6, 210, '20211001080101'),
(14, '20211001054546', '20211001083309', 11, 2, '20211001080101'),
(13, '20211001054546', '20211001075539', 4, 1000, '20211001080101'),
(12, '20211001054546', '20211001075539', 2, 1000, '20211001033310');

-- --------------------------------------------------------

--
-- 資料表結構 `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `m_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ss_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ss_snum` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sc_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ss_onum` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_date` datetime NOT NULL,
  `s_odate` datetime NOT NULL,
  `s_redate` datetime NOT NULL,
  `ss_memo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ss_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `sales`
--

INSERT INTO `sales` (`m_num`, `ss_num`, `ss_snum`, `sc_num`, `ss_onum`, `s_date`, `s_odate`, `s_redate`, `ss_memo`) VALUES
('20210901065241', '20211001073744', '123', '20211001054652', '123456789', '2021-10-05 07:38:10', '2021-10-07 11:31:57', '2021-10-07 09:22:32', '<p>1</p>\r\n'),
('20210901065241', '20211001080314', '333', '20211001054652', '', '2021-10-06 08:04:32', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '<p>123</p>\r\n');

-- --------------------------------------------------------

--
-- 資料表結構 `sales_product`
--

DROP TABLE IF EXISTS `sales_product`;
CREATE TABLE IF NOT EXISTS `sales_product` (
  `so_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sp_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_price` int(10) NOT NULL,
  `s_quantity` int(10) NOT NULL,
  `s_cost` int(10) NOT NULL,
  `pp_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`pp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `sales_product`
--

INSERT INTO `sales_product` (`so_num`, `sp_num`, `s_price`, `s_quantity`, `s_cost`, `pp_id`) VALUES
('20211001073744', '20211001075539', 2000, 12, 1000, 1),
('20211001073744', '20211001083309', 15, 22, 4, 2),
('20211001073744', '20211001075539', 2000, 6, 1000, 3),
('20211001073744', '20211001083309', 13, 3, 2, 4),
('20211001073744', '20211001075539', 2000, 1, 1000, 5),
('20211001073744', '20211001083309', 13, 8, 2, 6),
('20211001080314', '20211001075539', 2000, 1, 1000, 7),
('20211001080314', '20211001083309', 13, 1, 2, 8);

-- --------------------------------------------------------

--
-- 資料表結構 `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `m_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_num` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `s_pname` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `s_title` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_addr` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `s_mail` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `s_pcode` int(6) NOT NULL,
  `s_tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `s_memo` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`s_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `supplier`
--

INSERT INTO `supplier` (`m_num`, `s_num`, `s_username`, `s_pname`, `s_title`, `s_addr`, `s_mail`, `s_pcode`, `s_tel`, `s_phone`, `s_memo`) VALUES
('20210901065241', '20211001033310', '123供應商', 'OOO', 'XXXX', '11111111', '1111', 100, '8888888', '8888888', '<p>223 5454 5454</p>\r\n\r\n<p>1</p>\r\n\r\n<p>2</p>\r\n\r\n<p>3</p>\r\n\r\n<p>&nbsp;</p>\r\n'),
('20210901065241', '20211001080101', '11111', '111', '111', '111', '111', 111, '111', '111', '<p>1111</p>\r\n');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
