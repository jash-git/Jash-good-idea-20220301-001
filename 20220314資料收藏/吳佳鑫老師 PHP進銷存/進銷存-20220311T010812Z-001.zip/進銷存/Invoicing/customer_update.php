<?
session_start();
$m_num=$_SESSION["loginMember"];
require_once("db.php");

$data = [$_POST["username"],
		$_POST["pname"],
		$_POST["stitle"],
		$_POST["saddr"],
		$_POST["email"],
		$_POST["pcode"],
		$_POST["stel"],
		$_POST["sphone"],
		$_POST["memo"],
		$m_num,
		$_POST["c_id"]
		];

$query_RecLoginUpdate = "UPDATE customer SET c_username=? , c_pname=? , c_title=? , c_addr=? , c_mail=? , c_pcode=? , c_tel=? , c_phone=? , c_memo=?  WHERE m_num=? and c_num=?";
$stmt=$db_link->prepare($query_RecLoginUpdate);
$stmt->execute($data);
header("Location: index.php?a=customer_view&c_id=".$_POST["c_id"]);	

?>