<?
session_start();
$m_num=$_SESSION["loginMember"];
require_once("db.php");

		$date = date('Y-m-d H:i:s');

		//銷貨單 表頭資料更新
		$data=[$_POST["ssnum"], //訂單編號 (使用者KEYIN)
		$_POST["scnum"],
		$_POST["ssonum"],
		$_POST["memo"],//備註
		$m_num, //廠商代號
		$_POST["ss_id"] //銷貨代號 唯一值
		];
		
		$query_RecLoginUpdate = "UPDATE sales SET ss_snum=? , sc_num=? , ss_onum=?,ss_memo=?,s_redate=NOW() WHERE m_num=? and ss_num=?";
		$stmt = $db_link->prepare($query_RecLoginUpdate );
		$stmt->execute($data);

		
		//銷貨單 明細資料更新
		
		$xn = count($_POST["spnum"]); //取得資料筆數
		echo $xn;

		for($i=0;$i<$xn;$i++)
		{
		 $data[$i]=[
		 $_POST["spnum"][$i], //商品名稱
		 $_POST["sprice"][$i], // 單價
		 $_POST["pcost"][$i], // 商品成本
		 $_POST["puquantity"][$i], // 數量
		 $_POST["ppid"][$i], //唯一值 key
		 $_POST["ss_id"]//訂單編號
		 ];

		 $query_insert = "UPDATE sales_product SET sp_num=? , s_price=? , s_cost=? , s_quantity=? WHERE pp_id=? and so_num=?";	 
		 $stmt2 = $db_link->prepare($query_insert);
		 $stmt2->execute($data[$i]);

		}

		//銷貨單 明細資料 有新增產品狀況
		$ssid=$_POST["ss_id"];//訂單編號
		$stmt = $db_link->prepare("SELECT * FROM sales_product where so_num=?");//一般使用者
		$stmt->execute([$ssid]);
		$no=$stmt->rowCount();  //取得現有資料庫內筆數
		$xnn = count($_POST["spnum"]); //取得前端資料筆數
		echo $xno=$xnn-$no;
		if($xno>0) //xnn=3 no=2 xno=1
		{
		 for($i=0;$i<$xno;$i++)
		 {
		  $data[$i]=[$_POST["ss_id"], //銷貨單號 對應 銷貨作業主表
		  $_POST["spnum"][$i+$no], //商品名稱
		  $_POST["sprice"][$i+$no],//單價
		  $_POST["pcost"][$i+$no], // 商品成本
		  $_POST["puquantity"][$i+$no], // 數量
		  ];
		  $query_insert = "INSERT INTO Sales_product (so_num, sp_num, s_price,s_cost, s_quantity) VALUES (?, ?, ?, ?, ?)";
		  $stmt = $db_link->prepare($query_insert);
		  $stmt->execute($data[$i]);
		 }
		}
		
		header("Location: index.php?a=sales_list");	
//print_r($data);
?>