<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>會員資料</h3>
		<form id="form" action="member_update.php" method="post">
		<!-- 廠商編號 -->
<?
	$c_id=$_GET["c_id"];
	$stmt = $db_link->prepare("SELECT * FROM memberx WHERE m_num=?");
	$stmt->execute([$c_id]);
	$row=$stmt->fetch();
?>
		<input name="c_id" type="hidden" value="<?=$c_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">帳號：</label>
				<?=$row["m_id"];?>
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">密碼：</label>
				<?=$row["m_pwd"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">公司名稱：</label>
				<?=$row["m_username"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<?=$row["m_tel"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<?=$row["m_phone"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<?=$row["m_adr"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<?=$row["m_mail"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人：</label>
				<?=$row["m_pname"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">註冊日期：</label>
				<?=$row["m_jointime"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">登入時間：</label>
				<?=$row["m_logintime"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">登入次數：</label>
				<?=$row["m_login"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">權限：</label>
				<?=$row["m_power"];?>
			</div>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		  <!--
			<button type="submit" class="btn btn-default">送出</button>
			<button type="button" class="btn btn-default" onClick="history.back();">回上一頁</button>
		-->
		</form>
	</div>
<script>
$(function(){
        $('#form').validate({
       onkeyup: function(element, event) {
         //去除左側空白
		 /*
		 console.log(str.replace(/\s/g, '#'));                                // ##A#B##C###D#EF#
		 console.log(str.replace(/\s+/g, '#'));                             // #A#B#C#D#EF#  --> 代表1到多個
		 */
         var value = this.elementValue(element).replace(/^\s+/g, "");// ^表示匹配 \s 一個字串，s+表示許多 g表示全部匹配
         $(element).val(value);
        },
        rules: {
            /*
                required:必填
                noSpace:空白
                minlength:最小長度
                maxlength:最大長度
                email:信箱格式
                number:數字格式
                url:網址格式https://www.google.com
            */
          usereid: {
            required: true,
            noSpace: true
          },
		  userpasswd: {
            required: true,
            noSpace: true
          },
		  comname: {
            required: true,
            noSpace: true
          },
          comtel:{
            required: true,
            minlength: 8,
            number: true
          },
          comaddr: 'required',
          //url:{
          //  url: true
          //},
          email: {
            required: true,
            email: true
          }
        },
        messages: {
          fname: {
            required:'必填',
            noSpace: '不可有空白'
          },
          phone: {
            required:'必填',
            minlength:'不得少於8位',
            number:'電話需為數字'
          },
          address: '必填',
          email: {
            required: '必填',
            email: 'Email格式不正確'
          },
          url: '網址格式不正確'
        },
        submitHandler: function(form) {
          form.submit();
        }
  });
});
</script>
	