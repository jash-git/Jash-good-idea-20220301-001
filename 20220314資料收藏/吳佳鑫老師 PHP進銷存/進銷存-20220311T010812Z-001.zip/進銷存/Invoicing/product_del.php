<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>刪除產品資料</h3>
		<form id="form" action="" method="post">
<?
	$p_id=$_GET["p_id"];
	$stmt = $db_link->prepare("SELECT * FROM product WHERE m_num=? and p_num=?");
	$stmt->execute([$m_num,$p_id]);
	$row=$stmt->fetch();
?>
		<input name="p_id" type="hidden" value="<?=$p_id;?>">

			<div class="form-group form-inline">
				<label for="pnum">商品編號：</label>
				<?=$row["ps_num"];?>
			</div>
			<div class="form-group form-inline">
				<label for="pname">商品名稱：</label>
				<?=$row["p_name"];?>
			</div>
			<div class="form-group form-inline">
				<label for="snum">供應商：</label>
<?
	$s_id=$row["s_num"];
	$stmt2 = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt2->execute([$m_num,$s_id]);
	$row2=$stmt2->fetch();
?>
				<?=$row2["s_username"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">商品成本：</label>
				<?=$row["p_cost"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">單價：</label>
				<?=$row["p_price"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">庫存：</label>
				<?=$row["p_stock"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<?=$row["p_memo"];?>
			</div>
		
          <hr size="1" />
<?
$stmt->close;
if($_POST["action"]=="del"){
	echo "ok";
	$query = 'DELETE FROM product WHERE m_num=? and p_num=?';
	$stmt2 = $db_link->prepare($query);
	$stmt2->execute([$m_num,$p_id]);
	$stmt2->close;
	
	echo "<script> alert('產品資料刪除完成~');";
	echo "window.location.href='index.php?a=product_list';</script>";
}
?>
          <p align="center">
            <input name="action" type="hidden" id="action" value="del">
            <input type="submit" name="Submit" value="刪除">
            <input type="button" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>
