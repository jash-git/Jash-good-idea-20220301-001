<?
session_start();
$m_num=$_SESSION["loginMember"];
require_once("db.php");

		$date = date('Y-m-d H:i:s');
		
		//進貨單 表頭資料更新
		$data=[$_POST["punum"], //進貨單號 (使用者KEYIN)
		$date, //修改日期
		$_POST["memo"],//備註
		$m_num, //廠商代號
		$_POST["pu_id"] //進貨代號 唯一值
		];
		$query_RecLoginUpdate = "UPDATE purchase SET pu_snum=? , pu_redate=? , pu_memo=? WHERE m_num=? and pu_num=?";
		$stmt = $db_link->prepare($query_RecLoginUpdate );
		$stmt->execute($data);
		
		//進貨單 明細資料 有新增產品狀況
		$puid=$_POST["pu_id"];//進貨單編號
		$stmt = $db_link->prepare("SELECT * FROM purchase_product where pu_num=?");//一般使用者
		$stmt->execute([$puid]);
		$no=$stmt->rowCount();  //取得現有資料庫內筆數
		$xnn = count($_POST["pname"]); //取得前端資料筆數
		echo $xno=$xnn-$no;
		if($xno>0) //xnn=3 no=2 xno=1
		{
		 for($i=0;$i<$xno;$i++)
		 {
		  $data[$i]=[$_POST["pu_id"], //進貨單號 對應 進貨作業主表
		  $_POST["pnum"][$i+$no], //商品名稱
		  $_POST["snum"][$i+$no],//供應商
		  $_POST["pcost"][$i+$no], // 商品成本
		  $_POST["puquantity"][$i+$no], // 數量
		  ];
		  $query_insert = "INSERT INTO purchase_product (pu_num, ps_num, s_num,p_cost, pu_quantity) VALUES (?, ?, ?, ?, ?)";
		  $stmt = $db_link->prepare($query_insert);
		  $stmt->execute($data[$i]);
		 }
		}
		else
		{
		//進貨單 明細資料更新
		$xn = count($_POST["pname"]); //取得資料筆數
		//echo $xn;
		//echo $_POST["pname"][0]; //商品名稱
		//echo $_POST["ppid"][0];
		for($i=0;$i<$xn;$i++)
		{
		 $data[$i]=[
		 $_POST["pnum"][$i], //商品名稱
		 $_POST["puquantity"][$i], // 數量
		 $_POST["pcost"][$i], // 商品成本
		 $_POST["snum"][$i], // 供應商
		 $_POST["pu_id"], //進貨代號 
		 $_POST["ppid"][$i] //唯一值 key
		 ];
		 $query_insert = "UPDATE purchase_product SET ps_num=? , pu_quantity=? , p_cost=? , s_num=? WHERE pu_num=? and pp_id=?";	 
		 $stmt2 = $db_link->prepare($query_insert);
		 $stmt2->execute($data[$i]);
		}
		}
		
header("Location: index.php?a=purchase_list");	
?>