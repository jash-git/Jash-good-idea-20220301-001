<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>
<?php if(isset($_GET["registStats"]) && ($_GET["registStats"]=="1")){?>
<script>alert('申請帳號成功！');window.location.href='index.php';</script>
<?php }?>
	<div class="container">
		<h3>會員申請</h3>
		<p>
		  <?php if(isset($_GET["errMsg"]) && ($_GET["errMsg"]=="1")){?>
          <div class="errDiv"><strong style="color:red;">請輸入正確的資料，謝謝!!</strong></div>
          <?php }?>
		  <?php if(isset($_GET["errMsg"]) && ($_GET["errMsg"]=="2")){?>
          <div class="errDiv"><strong style="color:red;">已有相同帳號，謝謝!!</strong></div>
          <?php }?>
		</p>
		<form name="form" id="form" action="m_insert.php" method="post" onsubmit='return check_submit()'>
		<!-- 廠商編號 -->
<?
$date = new DateTime('first day of this month');
$c_id=$date->format('YmdHis');
?>
		<input name="c_id" type="hidden" value="<?=$c_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">*帳號：</label>
				<input type="text" name="usereid" class="form-control col-sm-3" id="usereid" placeholder="輸入帳號">
				<span class="tip1" style="color: red;">不得為空白</span>
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">*密碼：</label>
				<input type="password" name="userpasswd" class="form-control col-sm-3" id="userpasswd" placeholder="輸入密碼">
				<span class="tip2" style="color: red;">不得為空白</span>
			</div>
			<div class="form-group form-inline">
				<label for="passwdrecheck">*確認密碼：</label>
				<input type="password" name="passwdrecheck" class="form-control col-sm-3" id="passwdrecheck" placeholder="請確認輸入密碼">
				<span class="tip3" style="color: red;">不得為空白</span>
				<span class="tip33" style="color: red;">兩次輸入的密碼不一致</span>
			</div>
			<div class="form-group form-inline">
				<label for="username">*公司名稱：</label>
				<input type="text" name="comname" class="form-control col-sm-3" id="comname" placeholder="輸入公司名稱">
				<span class="tip4" style="color: red;">不得為空白</span>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">*聯絡電話：</label>
				<input type="text" name="comtel" class="form-control col-sm-3" id="comtel" placeholder="輸入電話號碼">
				<span class="tip5" style="color: red;">不得為空白</span>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">*行動電話：</label>
				<input type="text" name="comphone"  class="form-control col-sm-3" id="comphone" placeholder="輸入行動電話">
				<span class="tip6" style="color: red;">不得為空白</span>
				<span class="tip66" style="color: red;">不符合規則，請輸入「09xx-xxxxxx」</span>
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<input type="text" name="comaddr" class="form-control col-sm-3" id="comaddr" placeholder="輸入住址">
			</div>
			<div class="form-group form-inline">
				<label for="username">*E-Mail：</label>
				<input type="text" name="email" class="form-control col-sm-3" id="email" placeholder="輸入E-Mail">
				<span class="tip7" style="color: red;">不得為空白</span>
			</div>
			<div class="form-group form-inline">
				<label for="username">*聯絡人：</label>
				<input type="text" name="puser" class="form-control col-sm-3" id="puser" placeholder="輸入聯絡人姓名">
				<span class="tip8" style="color: red;">不得為空白</span>
			</div>

			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="submit" class="btn btn-outline-secondary" name="submit" id="send" value="送出申請">
            <input type="reset"  class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>
<script>
//document.form.submit2.disabled=true;
$(function(){
//初始
for(var i=1;i<=8;i++)
 $(".tip"+i).hide();
 $(".tip33").hide();
 $(".tip66").hide();
 
//凍結送出
//$('#send').attr('disabled', true);
var formData = $('#form').serializeArray();//表單內的值 作字串//表單內所有值 作陣列

//欄位失去焦點
$('#usereid').blur(function() { 
if($('#usereid').val()=="")	$(".tip1").show();
else $(".tip1").hide();
	});

$('#userpasswd').blur(function() { 
if($('#userpasswd').val()=="")	$(".tip2").show();
else $(".tip2").hide();
	});
	
$('#passwdrecheck').blur(function() { 
if($('#passwdrecheck').val()=="")	$(".tip3").show();
else 
{
$(".tip3").hide();
if($('#passwdrecheck').val()!=$('#userpasswd').val())
$(".tip33").show();
else
$(".tip33").hide();	
}
	});

$('#comname').blur(function() { 
if($('#comname').val()=="")	$(".tip4").show();
else $(".tip4").hide();
	});	

$('#comtel').blur(function() { 
if($('#comtel').val()=="")	$(".tip5").show();
else $(".tip5").hide();
	});	

var rule3=/^09\d{2}-\d{6}$/;
$('#comphone').blur(function() { 
if($('#comphone').val()=="") $(".tip6").show();
else $(".tip6").hide();
if(rule3.test($(this).val()))$(".tip66").hide();
else $(".tip66").show();
	});

$('#email').blur(function() { 
if($('#email').val()=="")	$(".tip7").show();
else $(".tip7").hide();
	});	
	
$('#puser').blur(function() { 
if($('#puser').val()=="")$(".tip8").show();
else 
$(".tip8").hide();
	});	

//------
});



</script>
	