<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>修改客戶資料</h3>
		<form id="form" action="customer_update.php" method="post">
		<!-- 廠商編號 -->
<?
	$c_id=$_GET["c_id"];
	$stmt = $db_link->prepare("SELECT * FROM customer WHERE m_num=? and c_num=?");
	$stmt->execute([$m_num,$c_id]);
	$row=$stmt->fetch();
?>
		<input name="c_id" type="hidden" value="<?=$c_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">客戶名稱：</label>
				<input type="text" name="username" class="form-control col-sm-3" id="username" placeholder="輸入客戶名稱" value="<?=$row["c_username"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">聯絡人：</label>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入聯絡人" value="<?=$row["c_pname"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人職稱：</label>
				<input type="text" name="stitle" class="form-control col-sm-3" id="stitle" placeholder="輸入聯絡人職稱" value="<?=$row["c_title"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<input type="text" name="stel" class="form-control col-sm-3" id="stel" placeholder="輸入電話號碼" value="<?=$row["c_tel"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<input type="text" name="sphone"  class="form-control col-sm-3" id="sphone" placeholder="輸入行動電話" value="<?=$row["c_phone"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">郵遞區號：</label>
				<input type="text" name="pcode" class="form-control col-sm-3" id="pcode" placeholder="輸入郵遞區號" value="<?=$row["c_pcode"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<input type="text" name="saddr" class="form-control col-sm-3" id="saddr" placeholder="輸入住址" value="<?=$row["c_addr"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<input type="text" name="email" class="form-control col-sm-3" id="email" placeholder="輸入E-Mail" value="<?=$row["c_mail"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"><?=$row["c_memo"];?></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="修改">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>

		</form>
	</div>
