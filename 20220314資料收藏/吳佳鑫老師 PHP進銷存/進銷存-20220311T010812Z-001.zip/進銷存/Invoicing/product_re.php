<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>修改產品資料</h3>
		<form id="form" action="p_update.php" method="post">
		<!-- 廠商編號 -->
<?
	$p_id=$_GET["p_id"];
	$stmt = $db_link->prepare("SELECT * FROM product WHERE m_num=? and p_num=?");
	$stmt->execute([$m_num,$p_id]);
	$row=$stmt->fetch();
?>
		<input name="p_id" type="hidden" value="<?=$p_id;?>">

			<div class="form-group form-inline">
				<label for="pnum">商品編號：</label>
				<input type="text" name="pnum" class="form-control col-sm-3" id="pnum" placeholder="輸入商品編號" value="<?=$row["ps_num"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="pname">商品名稱：</label>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入商品名稱" value="<?=$row["p_name"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="snum">供應商：</label>
<?
	$s_id=$row["s_num"];
	$stmt2 = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt2->execute([$m_num,$s_id]);
	$row2=$stmt2->fetch();
?>
				<input type="readonly" name="snum" class="form-control col-sm-3" id="snum" placeholder="選擇供應商" value="<?=$row2["s_username"];?>">
				<input type="hidden" name="snumx" class="form-control col-sm-3" id="snumx" placeholder="選擇供應商" value="<?=$s_id;?>">		
			</div>
			
			<div class="form-group form-inline" id="div1">
			<ul class="art-vmenu">
<?
	$stmt3 = $db_link->prepare("SELECT * FROM supplier where m_num=?");//一般使用者
	$stmt3->execute([$m_num]);
	while($row3=$stmt3->fetch()){
?>
				<li><a href="#" ><span class="l"></span><span class="r"></span>
				<span class="t"><?=$row3["s_username"];?></span>
				<span class="x" style="display:none;"><?=$row3["s_num"];?></span>
					</a>
				</li> 
<?
}
?>		
			</ul>
			</div>
			<div class="form-group form-inline">
				<label for="username">商品成本：</label>
				<input type="text" name="pcost" class="form-control col-sm-3" id="pcost" placeholder="輸入商品成本" value="<?=$row["p_cost"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">單價：</label>
				<input type="text" name="pprice" class="form-control col-sm-3" id="pprice" placeholder="輸入單價" value="<?=$row["p_price"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">庫存：</label>
				<input type="text" name="pstock"  class="form-control col-sm-3" id="pstock" placeholder="輸入庫存數量" value="<?=$row["p_stock"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"><?=$row["p_memo"];?></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="修改">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>

		</form>
	</div>

<script>
$(document).ready(function() 
 {
 $("#div1").hide();
 
$("#snum").click(function(){
  $("#div1").fadeToggle();
});

    $('ul.art-vmenu li').click(function(e) 
    { 
	 var xxx=$(this).find("span.t").text();
	 var xxxx=$(this).find("span.x").text();
	 $("#snum").val(xxx);
	 $("#snumx").val(xxxx);
    });
 });
</script>