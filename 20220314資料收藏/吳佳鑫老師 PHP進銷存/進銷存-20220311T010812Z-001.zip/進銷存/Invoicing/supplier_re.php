<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>修改供應商資料</h3>
		<form id="form" action="supplier_update.php" method="post">
		<!-- 廠商編號 -->
<?
	$s_id=$_GET["s_id"];
	$stmt = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt->execute([$m_num,$s_id]);
	$row=$stmt->fetch();
?>
		<input name="s_id" type="hidden" value="<?=$s_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">供應商名稱：</label>
				<input type="text" name="username" class="form-control col-sm-3" id="username" placeholder="輸入供應商名稱" value="<?=$row["s_username"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">聯絡人：</label>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入聯絡人" value="<?=$row["s_pname"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人職稱：</label>
				<input type="text" name="stitle" class="form-control col-sm-3" id="stitle" placeholder="輸入聯絡人職稱" value="<?=$row["s_title"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<input type="text" name="stel" class="form-control col-sm-3" id="stel" placeholder="輸入電話號碼" value="<?=$row["s_tel"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<input type="text" name="sphone"  class="form-control col-sm-3" id="sphone" placeholder="輸入行動電話" value="<?=$row["s_phone"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">郵遞區號：</label>
				<input type="text" name="pcode" class="form-control col-sm-3" id="pcode" placeholder="輸入郵遞區號" value="<?=$row["s_pcode"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<input type="text" name="saddr" class="form-control col-sm-3" id="saddr" placeholder="輸入住址" value="<?=$row["s_addr"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<input type="text" name="email" class="form-control col-sm-3" id="email" placeholder="輸入E-Mail" value="<?=$row["s_mail"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"><?=$row["s_memo"];?></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="修改">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>

		</form>
	</div>
