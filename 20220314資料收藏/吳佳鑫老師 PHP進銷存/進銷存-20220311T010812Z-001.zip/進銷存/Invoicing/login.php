<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Content -->
<?
//檢查是否經過登入，若有登入則重新導向
if(isset($_SESSION["loginMember"]) && ($_SESSION["loginMember"]!="")){
	//若帳號等級為 member 則導向會員中心
	if($_SESSION["memberLevel"]=="member"){
		//header("Location: member_center.php");
	//否則則導向管理中心
	}else{
		//header("Location: member_admin.php");	
	}
}

//執行會員登入
$m_id=$_POST["userid"];
$m_pwd=$_POST["userpasswd"];

if(isset($_POST["userid"]) && isset($_POST["userpasswd"])){
	$stmt = $db_link->prepare("SELECT m_id,m_pwd,m_num,m_power FROM memberx WHERE m_id=? and m_pwd=?");
	$stmt->execute([$m_id,$m_pwd]);
	$no=$stmt->rowCount();  
	$row=$stmt->fetch();
	$m_num = $row["m_num"];
	$level = $row["m_power"];
	
	if ($no>0){
		echo "帳密比對OK";
		//計算登入次數及更新登入時間
		$query_RecLoginUpdate = "UPDATE memberx SET m_logintime=NOW(),m_login=m_login+1 WHERE m_num=?";
		$stmt=$db_link->prepare($query_RecLoginUpdate);
		$stmt->execute([$m_num]);
		//設定登入者的名稱及等級
		$_SESSION["loginMember"]=$m_num;
		$_SESSION["memberLevel"]=$level;

		//若帳號等級為 member 則導向會員中心
		if($_SESSION["memberLevel"]=="0"){
			header("Location: index.php?a=member_center");
		//否則則導向管理中心
		}else{
			header("Location: index.php?a=admin");	
		}
		//
		
	}else{
		echo "ERROR";
		header("Location: index.php?errMsg=1");
	}
}
?>
<center>
<?php if(isset($_GET["errMsg"]) && ($_GET["errMsg"]=="1")){?>
          <div class="errDiv"> <b>登入帳號或密碼錯誤！</b></div>
<?php }?>
		  
	<div class="container">
		<h3>進銷存管理系統</h3>
		<form action="#" method="post"  class="form-horizontal">
			<div class="form-group">
				<label for="useremail" class="col-sm-2 control-label">管理者帳號</label>
				<div class="col-sm-6">
					<input type="text" name="userid" class="form-control" id="usereid" placeholder="輸入帳號">
				</div>
			</div>
			<div class="form-group">
				<label for="userpasswd" class="col-sm-2 control-label">管理者密碼</label>
				<div class="col-sm-6">
					<input type="password" name="userpasswd" class="form-control" id="userpasswd" placeholder="輸入密碼">
				</div>
			</div>
			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
					<a class="btn btn-outline-secondary" href="index.php?a=member_add" role="button">申請</a>&nbsp
					<button type="submit" width="100px" class="btn btn-outline-secondary">登入管理</button>&nbsp
					<button type="button" class="btn btn-outline-secondary" onClick="history.back();">回上一頁</button>&nbsp
					<a class="btn btn-outline-secondary" href="index.php?a=member_forget" role="button">忘記密碼</a>
				</div>
			</div>
		</form>
	</div>