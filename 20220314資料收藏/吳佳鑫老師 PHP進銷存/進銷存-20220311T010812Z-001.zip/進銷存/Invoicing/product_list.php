<!--
https://datatables.net/extensions/fixedheader/examples/options/columnFiltering.html 
-->
<link href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/fixedheader/3.1.9/css/fixedHeader.dataTables.min.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.9/js/dataTables.fixedHeader.min.js"></script>
<style>
thead input {
        width: 100%;
    }
</style>
<script>
$(document).ready(function () {
    // Setup - add a text input to each footer cell
    $('#example thead tr')
        .clone(true)
        .addClass('filters')
        .appendTo('#example thead');
 
    var table = $('#example').DataTable({
        orderCellsTop: true,
        fixedHeader: true,
        initComplete: function () {
            var api = this.api();
 
            // For each column
            api
                .columns()
                .eq(0)
                .each(function (colIdx) {
                    // Set the header cell to contain the input element
                    var cell = $('.filters th').eq(
                        $(api.column(colIdx).header()).index()
                    );
                    var title = $(cell).text();
                    $(cell).html('<input type="text" placeholder="' + title + '" />');
 
                    // On every keypress in this input
                    $(
                        'input',
                        $('.filters th').eq($(api.column(colIdx).header()).index())
                    )
                        .off('keyup change')
                        .on('keyup change', function (e) {
                            e.stopPropagation();
 
                            // Get the search value
                            $(this).attr('title', $(this).val());
                            var regexr = '({search})'; //$(this).parents('th').find('select').val();
 
                            var cursorPosition = this.selectionStart;
                            // Search the column for that value
                            api
                                .column(colIdx)
                                .search(
                                    this.value != ''
                                        ? regexr.replace('{search}', '(((' + this.value + ')))')
                                        : '',
                                    this.value != '',
                                    this.value == ''
                                )
                                .draw();
 
                            $(this)
                                .focus()[0]
                                .setSelectionRange(cursorPosition, cursorPosition);
                        });
                });
        },
    });
});
</script>
<p align="right"><a class="btn btn-outline-secondary" href="index.php?a=product_add">新增</a></p>
<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>產品名稱</th>
                <th>庫存</th>
                <th>成本 / 單價</th>
                <th>管理</th>
            </tr>
        </thead>
        <tbody>
<?
	$stmt = $db_link->prepare("SELECT * FROM product where m_num=?");//一般使用者
	$stmt->execute([$m_num]);
	$no=$stmt->rowCount();  
	while($row=$stmt->fetch()){
?>
            <tr>
                <td><a href="index.php?a=product_view&p_id=<?=$row["p_num"];?>"><?=$row["p_name"];?></a></td>
                <td><?=$row["p_stock"];?></td>
                <td>$<?=$row["p_cost"];?> / $<?=$row["p_price"];?></td>
                <td><a class="btn btn-outline-secondary" href="index.php?a=product_re&p_id=<?=$row["p_num"];?>" role="button">修改</a> &nbsp <a class="btn btn-outline-secondary" href="index.php?a=product_del&p_id=<?=$row["p_num"];?>" role="button">刪除</a></td>
            </tr>
<?
}
?>
        </tbody>
        <tfoot>
            <tr>
                <th>產品名稱</th>
                <th>庫存</th>
                <th>成本 / 單價</th>
                <th>管理</th>
            </tr>
        </tfoot>
    </table>
             