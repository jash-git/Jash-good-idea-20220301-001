<?
session_start();
$m_num=$_SESSION["loginMember"];
require_once("db.php");

$data = [$_POST["username"],
		$_POST["pname"],
		$_POST["stitle"],
		$_POST["saddr"],
		$_POST["email"],
		$_POST["pcode"],
		$_POST["stel"],
		$_POST["sphone"],
		$_POST["memo"],
		$m_num,
		$_POST["s_id"]
		];

$query_RecLoginUpdate = "UPDATE supplier SET s_username=? , s_pname=? , s_title=? , s_addr=? , s_mail=? , s_pcode=? , s_tel=? , s_phone=? , s_memo=?  WHERE m_num=? and s_num=?";
$stmt=$db_link->prepare($query_RecLoginUpdate);
$stmt->execute($data);
header("Location: index.php?a=supplier_view&s_id=".$_POST["s_id"]);	

?>