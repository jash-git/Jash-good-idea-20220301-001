<?
session_start();
$m_num=$_SESSION["loginMember"];
require_once("db.php");

$data = [$_POST["pnum"],
		$_POST["pname"],
		$_POST["snumx"],
		$_POST["pcost"],
		$_POST["pprice"],
		$_POST["pstock"],
		$_POST["memo"],
		$m_num,
		$_POST["p_id"]
		];

$query_RecLoginUpdate = "UPDATE product SET ps_num=? , p_name=? , s_num=? , p_cost=? , p_price=? , p_stock=? , p_memo=?  WHERE m_num=? and p_num=?";
$stmt=$db_link->prepare($query_RecLoginUpdate);
$stmt->execute($data);
header("Location: index.php?a=product_view&p_id=".$_POST["p_id"]);	

?>