<?

session_start();
require_once("db.php");

$m_num = $_SESSION["loginMember"];

if(isset($_POST["action"])&&($_POST["action"]=="add")){

		echo "可以新增";
		$date = date('Y-m-d H:i:s');

		//銷貨單 表頭資料寫入
		$data=[$m_num, //廠商代號
		$_POST["ss_id"], //銷貨單號 唯一值
		$_POST["ssnum"], //銷貨單號 (使用者KEYIN)
		$_POST["scnum"], //客戶名稱
		$date, //銷貨單日期
		$_POST["memo"]//備註
		];
		$query_insert = "INSERT INTO sales (m_num, ss_num, ss_snum,sc_num,s_date,ss_memo) VALUES (?, ?, ?, ?, ?,?)";
		$stmt = $db_link->prepare($query_insert);
		$stmt->execute($data);


		//銷貨單 明細資料寫入
		$xn = count($_POST["spnum"]); //取得資料筆數
		echo $xn;
		
		for($i=0;$i<$xn;$i++)
		{
		 $data[$i]=[$_POST["ss_id"], //銷貨單號 對應 銷貨作業主表
		 $_POST["spnum"][$i], //商品名稱
		 $_POST["sprice"][$i],//單價
		 $_POST["pcost"][$i], // 商品成本
		 $_POST["puquantity"][$i], // 數量
		 ];
		 $query_insert = "INSERT INTO Sales_product (so_num, sp_num, s_price,s_cost, s_quantity) VALUES (?, ?, ?, ?, ?)";
		 $stmt = $db_link->prepare($query_insert);
		 $stmt->execute($data[$i]);
		}
		
		header("Location: index.php?a=sales_list");	
//	print_r($data);

}

?>