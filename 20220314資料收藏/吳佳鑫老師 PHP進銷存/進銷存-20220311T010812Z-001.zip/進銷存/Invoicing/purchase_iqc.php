<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>查看進貨單</h3>
		<form id="form" action="" method="post">
<?
	$pu_id=$_GET["pu_id"];
	$stmt = $db_link->prepare("SELECT * FROM purchase WHERE m_num=? and pu_num=?");
	$stmt->execute([$m_num,$pu_id]);
	$row=$stmt->fetch();
?>
		<input name="pu_id" type="hidden" value="<?=$pu_id;?>">

			<div class="form-group form-inline">
				<label for="punum">進貨單號：</label>
				<?=$row["pu_snum"];?>
			</div>
			<div class="form-group form-inline">
				<label for="punum">進貨日期：</label>
				<?=$row["pu_date"];?> / 修改日期：<?=$row["pu_redate"];?>
			</div>
			<div class="form-group form-inline">
				<label for="punum">入庫日期：</label>
				<?
				if($row["pu_idate"]=="0000-00-00 00:00:00")
				echo '<b style="color:red;">未入庫</b>';
				else
				echo '<b style="color:blue;">'.$row["pu_idate"].'</b>';
				
				?> 
			</div>
<hr>
<!-- -->
	<div class="container">
		<div class="row">
			<div class="col">
				<h3>進貨明細</h3>
				<table class="table">
					<thead>
						<tr>
							<th>商品名稱</th>
							<th>供應商</th>
							<th>成本</th>
							<th>數量</th>
						</tr>
					</thead>
					<tbody>
<?
	$stmt2 = $db_link->prepare("SELECT * FROM purchase,purchase_product where purchase.pu_num=purchase_product.pu_num and purchase.m_num=? and purchase.pu_num=? ");//一般使用者
	$stmt2->execute([$m_num,$pu_id]);
	while($row2=$stmt2->fetch()){
		$p_num = $row2["ps_num"]; //產品編號	
	$stmt3 = $db_link->prepare("SELECT * FROM product WHERE m_num=? and p_num=?");
	$stmt3->execute([$m_num,$p_num]);
	$row3=$stmt3->fetch();
		$s_num=$row2["s_num"]; //供應商編號
	$stmt4 = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt4->execute([$m_num,$s_num]);
	$row4=$stmt4->fetch();
?>
						<tr>
							<td><a href="index.php?a=product_view&p_id=<?=$p_num;?>"><?=$row3["p_name"];?></a></td>
							<td><a href="index.php?a=supplier_view&s_id=<?=$s_num;?>"><?=$row4["s_username"];?></a></td>
							<td>$<?=$row2["p_cost"];?></td>
							<td><?=$row2["pu_quantity"];?></td>
						</tr>
<?
}
?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- -->
<hr>
<?
$stmt->close;
if($_POST["action"]=="iqc"){
	echo "ok";
	$query_RecLoginUpdate = "UPDATE purchase SET pu_idate=NOW()  WHERE m_num=? and pu_num=?";
	$stmt2 = $db_link->prepare($query_RecLoginUpdate);
	$stmt2->execute([$m_num,$pu_id]);
	$stmt2->close;
	
	//修改庫存數 & 成本
	$stmt6 = $db_link->prepare("SELECT * FROM purchase_product where pu_num=? ");//一般使用者
	$stmt6->execute([$pu_id]);
	while($row6=$stmt6->fetch()){
		//取得進貨明細-產品數量
		$pnum=$row6["ps_num"];//商品代號
		$ppid=$row6["pp_id"];//唯一值
		
		$stmt66 = $db_link->prepare("SELECT * FROM purchase_product where pu_num=? and ps_num=? and pp_id=? ");//一般使用者
		$stmt66->execute([$pu_id,$pnum,$ppid]);
		$row66=$stmt66->fetch();
		$puquantity=$row66["pu_quantity"];
		//$stmt66->close;
		echo $puquantity;

		//更新商品庫存數

		$query_RecLoginUpdate = "UPDATE product SET p_stock=(p_stock+?)  WHERE m_num=? and p_num=?";
		$stmt666 = $db_link->prepare($query_RecLoginUpdate);
		$stmt666->execute([$puquantity,$m_num,$pnum]);
		$stmt666->close;

	}	
	
	//echo "<script> alert('入庫完成~');";
	//echo "window.location.href='index.php?a=purchase_list';</script>";
}
?>

			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<?=$row["pu_memo"];?>
				</div>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="iqc">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="入庫">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>
