<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>刪除進貨單</h3>
		<form id="form" action="" method="post">
<?
	$pu_id=$_GET["pu_id"];
	$stmt = $db_link->prepare("SELECT * FROM purchase WHERE m_num=? and pu_num=?");
	$stmt->execute([$m_num,$pu_id]);
	$row=$stmt->fetch();
?>
		<input name="pu_id" type="hidden" value="<?=$pu_id;?>">

			<div class="form-group form-inline">
				<label for="punum">進貨單號：</label>
				<?=$row["pu_snum"];?>
			</div>
			<div class="form-group form-inline">
				<label for="punum">進貨日期：</label>
				<?=$row["pu_date"];?> / 修改日期：<?=$row["pu_redate"];?>
			</div>
			<div class="form-group form-inline">
				<label for="punum">入庫日期：</label>
				<?
				if($row["pu_idate"]=="0000-00-00 00:00:00")
				echo '<b style="color:red;">未入庫</b>';
				else
				echo '<b style="color:blue;">'.$row["pu_idate"].'</b>';
				
				?> 
			</div>
<hr>
<!-- -->
	<div class="container">
		<div class="row">
			<div class="col">
				<h3>進貨明細</h3>
				<table class="table">
					<thead>
						<tr>
							<th>商品名稱</th>
							<th>供應商</th>
							<th>成本</th>
							<th>數量</th>
						</tr>
					</thead>
					<tbody>
<?
	$stmt2 = $db_link->prepare("SELECT * FROM purchase,purchase_product where purchase.pu_num=purchase_product.pu_num and purchase.m_num=? and purchase.pu_num=? ");//一般使用者
	$stmt2->execute([$m_num,$pu_id]);
	while($row2=$stmt2->fetch()){
		$p_num = $row2["ps_num"]; //產品編號	
	$stmt3 = $db_link->prepare("SELECT * FROM product WHERE m_num=? and p_num=?");
	$stmt3->execute([$m_num,$p_num]);
	$row3=$stmt3->fetch();
		$s_num=$row2["s_num"]; //供應商編號
	$stmt4 = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt4->execute([$m_num,$s_num]);
	$row4=$stmt4->fetch();
?>
						<tr>
							<td><?=$row3["p_name"];?></td>
							<td><?=$row4["s_username"];?></td>
							<td>$<?=$row2["p_cost"];?></td>
							<td><?=$row2["pu_quantity"];?></td>
						</tr>
<?
}
?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- -->
<hr>
<?
$stmt->close;
if($_POST["action"]=="del"){
	echo "ok";
	$query = 'DELETE FROM purchase WHERE m_num=? and pu_num=?';
	$stmt99 = $db_link->prepare($query);
	$stmt99->execute([$m_num,$pu_id]);
	$stmt99->close;
	
	$query = 'DELETE FROM purchase_product WHERE pu_num=?';
	$stmt99 = $db_link->prepare($query);
	$stmt99->execute([$pu_id]);
	$stmt99->close;
	
	echo "<script> alert('產品資料刪除完成~');";
	echo "window.location.href='index.php?a=purchase_list';</script>";
}
?>

			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<?=$row["pu_memo"];?>
				</div>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="del">
            <input type="submit" name="Submit" value="刪除">
            <input type="button" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>
