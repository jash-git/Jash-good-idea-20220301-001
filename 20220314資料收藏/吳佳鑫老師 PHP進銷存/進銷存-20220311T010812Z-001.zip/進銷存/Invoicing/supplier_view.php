<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>供應商資料</h3>
		<!-- 廠商編號 -->
<?
	$s_id=$_GET["s_id"];
	$stmt = $db_link->prepare("SELECT * FROM supplier WHERE m_num=? and s_num=?");
	$stmt->execute([$m_num,$s_id]);
	$row=$stmt->fetch();
?>	
			<div class="form-group form-inline">
				<label for="usereid">供應商名稱：</label>
				<?=$row["s_username"];?>
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">聯絡人：</label>
				<?=$row["s_pname"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人職稱：</label>
				<?=$row["s_title"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<?=$row["s_tel"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<?=$row["s_phone"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">郵遞區號：</label>
				<?=$row["s_pcode"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<?=$row["s_addr"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<?=$row["s_mail"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<div><?=$row["s_memo"];?></div>
			</div>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>
<script>
$(function(){
        $('#form').validate({
       onkeyup: function(element, event) {
         //去除左側空白
		 /*
		 console.log(str.replace(/\s/g, '#'));                                // ##A#B##C###D#EF#
		 console.log(str.replace(/\s+/g, '#'));                             // #A#B#C#D#EF#  --> 代表1到多個
		 */
         var value = this.elementValue(element).replace(/^\s+/g, "");// ^表示匹配 \s 一個字串，s+表示許多 g表示全部匹配
         $(element).val(value);
        },
        rules: {
            /*
                required:必填
                noSpace:空白
                minlength:最小長度
                maxlength:最大長度
                email:信箱格式
                number:數字格式
                url:網址格式https://www.google.com
            */
          usereid: {
            required: true,
            noSpace: true
          },
		  userpasswd: {
            required: true,
            noSpace: true
          },
		  comname: {
            required: true,
            noSpace: true
          },
          comtel:{
            required: true,
            minlength: 8,
            number: true
          },
          comaddr: 'required',
          //url:{
          //  url: true
          //},
          email: {
            required: true,
            email: true
          }
        },
        messages: {
          fname: {
            required:'必填',
            noSpace: '不可有空白'
          },
          phone: {
            required:'必填',
            minlength:'不得少於8位',
            number:'電話需為數字'
          },
          address: '必填',
          email: {
            required: '必填',
            email: 'Email格式不正確'
          },
          url: '網址格式不正確'
        },
        submitHandler: function(form) {
          form.submit();
        }
  });
});
</script>
	