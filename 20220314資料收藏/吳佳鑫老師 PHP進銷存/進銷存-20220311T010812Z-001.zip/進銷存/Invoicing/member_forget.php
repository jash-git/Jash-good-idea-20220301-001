<?
//確認會員
$m_id=$_POST["userid"];
$m_mail=$_POST["usermail"];
if(isset($m_id) && isset($m_mail)){
$stmt = $db_link->prepare("SELECT * FROM memberx WHERE m_id=? and m_mail=?");
$stmt->execute([$m_id,$m_mail]);
$no=$stmt->rowCount(); 
$row=$stmt->fetch();
$m_num = $row["m_num"];
$mailto = $row["m_mail"];

	if($no>0)
	{
	 $mailsend="mailforget";
	 include("sendmail.php");
	}
	else
	{
	 header("Location: index.php?a=member_forget&errMsg=1");
	}	 
}


?>
<!-- Content -->
<?php if(isset($_GET["mailStats"]) && ($_GET["mailStats"]=="1")){?>
<script>alert('密碼信補寄成功！');window.location.href='index.php';</script>
<?php }?>
<center>	  
	<div class="container">
		<h3>進銷存管理系統-忘記密碼</h3>
		<p><b>請輸入您申請的帳號，系統將自動產生一個十位數的密碼寄到您註冊的信箱。</b>
		<?php if(isset($_GET["errMsg"]) && ($_GET["errMsg"]=="1")){?>
          <div class="errDiv"><strong style="color:red;">請輸入正確的帳號或E-Mail，謝謝!!</strong></div>
          <?php }?>
		</p>
		<form action="#" method="post"  class="form-horizontal">
			<div class="form-group">
				<label for="userid" class="col-sm-2 control-label">帳號</label>
				<div class="col-sm-6">
					<input type="text" name="userid" class="form-control" id="usereid" placeholder="輸入帳號">
				</div>
			</div>
			<div class="form-group">
				<label for="usermail" class="col-sm-2 control-label">申請的E-mail</label>
				<div class="col-sm-6">
					<input type="text" name="usermail" class="form-control" id="usermail" placeholder="輸入E-mail">
				</div>
			</div>
			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
					<a class="btn btn-outline-secondary" href="index.php?a=member_add" role="button">申請</a>&nbsp
					<button type="submit" width="100px" class="btn btn-outline-secondary">補寄密碼信</button>&nbsp
					<button type="button" class="btn btn-outline-secondary" onClick="history.back();">回上一頁</button>
				</div>
			</div>
		</form>
	</div>