<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>
	<div class="container">
		<h3>查看銷貨單</h3>
		<form id="form" action="" method="post">
<?
	$ss_id=$_GET["ss_id"];
	$stmt = $db_link->prepare("SELECT * FROM sales WHERE m_num=? and ss_num=?");
	$stmt->execute([$m_num,$ss_id]);
	$row=$stmt->fetch();
?>

		<input name="ss_id" type="hidden" value="<?=$ss_id;?>">

			<div class="form-group form-inline">
				<label for="ssnum">訂單編號：</label>
				<?=$row["ss_snum"];?>
			</div>

			<div class="form-group form-inline">
				<label for="pname">客戶名稱：</label>
<?
$scnum=$row["sc_num"];
$stmt2 = $db_link->prepare("SELECT * FROM  customer WHERE m_num=? and c_num=?");
$stmt2->execute([$m_num,$scnum]);
$row2=$stmt2->fetch();
echo $row2["c_username"];
?>
			</div>
			<div class="form-group form-inline">
				<label for="ssnum">訂單日期：</label>
				<?=$row["s_date"];?>
			</div>
			<div class="form-group form-inline">
				<label for="ssnum">物流單號：</label>
<?
if($row["ss_onum"]=="")
{
?>
				<input type="text" name="ssonum" class="form-control col-sm-3" id="ssonum" placeholder="輸入物流單號">
				<input type="submit" name="Submit" value="出貨">
<?
}
else
{
echo '<b style="color:blue;">'.$row["ss_onum"].'</b>';
echo "&nbsp&nbsp出貨日期：&nbsp";
echo '<b style="color:blue;">'.$row["s_odate"].'</b>';
}
?>
			</div>
<hr>
<!-- -->
	<div class="container">
		<div class="row">
			<div class="col">
				<h3>銷貨明細</h3> 
				<table class="table">
					<thead>
						<tr>
							<th>商品名稱</th>
							<th>單價</th>
							<th>數量</th>
							<th>小計</th>
							<th>成本</th>
							<th>毛利小計</th>
						</tr>
					</thead>
					<tbody class="input_fields_wrap">
<?
$stmt3 = $db_link->prepare("SELECT * FROM Sales_product where so_num=? ");//一般使用者
$stmt3->execute([$ss_id]);
while($row3=$stmt3->fetch()){
?>
						<tr>
							<td><?=$row3["sp_num"];?></td>
							<td>$<?=$row3["s_price"];?></td>
							<td><?=$row3["s_quantity"];?></td>
							<td>$
							<?
							echo $mtotla=$row3["s_price"]*$row3["s_quantity"];
							?>
							</td>
							<td>$<?=$row3["s_cost"];?></td>
							<td>$
							<?
							echo ($row3["s_cost"]*$row3["s_quantity"]);
							?>
							</td>
						</tr>
<?
}
?>
						<tr>
							<td></td>
							<td></td>
							<td>訂單總計:</td>
							<td>$
<?
	$stmt4 = $db_link->prepare("SELECT *, SUM(s_quantity*s_price) as mtotal,SUM(s_quantity*s_cost) as stotal FROM Sales_product where so_num=? ");//一般使用者
	$stmt4->execute([$ss_id]);
	$row4=$stmt4->fetch();
	echo $row4["mtotal"];
?>
							</td>
							<td>毛利總計:</td>
							<td>$
<?
	echo $row4["stotal"];
?>
							</td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td>總計利潤:</td>
							<td>$
<?
	echo $row4["mtotal"]-$row4["stotal"];
?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- -->
<hr>
<?
$stmt->close;
if($_POST["action"]=="oqc"){
	echo "ok";
	$ssonum=$_POST["ssonum"];
	$query_RecLoginUpdate = "UPDATE sales SET s_odate=NOW(),ss_onum=?  WHERE m_num=? and ss_num=?";
	$stmt5 = $db_link->prepare($query_RecLoginUpdate);
	$stmt5->execute([$ssonum,$m_num,$ss_id]);
	$stmt5->close;
	
	echo "<script> alert('出貨完成~');";
	echo "window.location.href='index.php?a=sales_list';</script>";
}
?>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<?=$row["ss_memo"];?>
			</div>	
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="oqc">
            <input type="button" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
	</div>
		</form>
