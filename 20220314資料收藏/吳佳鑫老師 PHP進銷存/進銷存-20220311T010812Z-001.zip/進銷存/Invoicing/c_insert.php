<?
session_start();
require_once("db.php");

$m_num = $_SESSION["loginMember"];

if(isset($_POST["action"])&&($_POST["action"]=="add")){

		echo "可以新增";
		try {
			
$data = [$m_num,
		$_POST["c_id"],
		$_POST["username"],
		$_POST["pname"],
		$_POST["stitle"],
		$_POST["saddr"],
		$_POST["email"],
		$_POST["pcode"],
		$_POST["stel"],
		$_POST["sphone"],
		$_POST["memo"]
		];
		
		$query_insert = "INSERT INTO customer (m_num, c_num, c_username, c_pname, c_title, c_addr, c_mail, c_pcode, c_tel, c_phone, c_memo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
		
		$stmt = $db_link->prepare($query_insert);

		$stmt->execute($data);
		header("Location: index.php?a=customer_list");	
		
		}catch (PDOException $ex) {
			error($ex);
		}
}

?>