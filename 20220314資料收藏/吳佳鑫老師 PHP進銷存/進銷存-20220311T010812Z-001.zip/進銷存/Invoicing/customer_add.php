<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>新增客戶</h3>
		<form id="form" action="c_insert.php" method="post">
		<!-- 客戶編號 -->
<?
$date = new DateTime('first day of this month');
$c_id=$date->format('YmdHis');
?>
		<input name="c_id" type="hidden" value="<?=$c_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">客戶名稱：</label>
				<input type="text" name="username" class="form-control col-sm-3" id="username" placeholder="輸入供應商名稱">
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">聯絡人：</label>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入聯絡人">
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人職稱：</label>
				<input type="text" name="stitle" class="form-control col-sm-3" id="stitle" placeholder="輸入聯絡人職稱">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<input type="text" name="stel" class="form-control col-sm-3" id="stel" placeholder="輸入電話號碼">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<input type="text" name="sphone"  class="form-control col-sm-3" id="sphone" placeholder="輸入行動電話">
			</div>
			<div class="form-group form-inline">
				<label for="username">郵遞區號：</label>
				<input type="text" name="pcode" class="form-control col-sm-3" id="pcode" placeholder="輸入郵遞區號">
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<input type="text" name="saddr" class="form-control col-sm-3" id="saddr" placeholder="輸入住址">
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<input type="text" name="email" class="form-control col-sm-3" id="email" placeholder="輸入E-Mail">
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="add">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="送出">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>