<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>新增產品</h3>
		<form id="form" action="p_insert.php" method="post">
		<!-- 供應商編號 -->
<?
$date = new DateTime('first day of this month');
$p_id=$date->format('YmdHis');
?>
		<input name="p_id" type="hidden" value="<?=$p_id;?>">

			<div class="form-group form-inline">
				<label for="pnum">商品編號：</label>
				<input type="text" name="pnum" class="form-control col-sm-3" id="pnum" placeholder="輸入商品編號">
			</div>
			<div class="form-group form-inline">
				<label for="pname">商品名稱：</label>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入商品名稱">
			</div>
			<div class="form-group form-inline">
				<label for="snum">供應商：</label>
				<input type="readonly" name="snum" class="form-control col-sm-3" id="snum" placeholder="選擇供應商">
				<input type="hidden" name="snumx" class="form-control col-sm-3" id="snumx" placeholder="選擇供應商" >		
			</div>
			
			<div class="form-group form-inline" id="div1">
			<ul class="art-vmenu">
<?
	$stmt = $db_link->prepare("SELECT * FROM supplier where m_num=?");//一般使用者
	$stmt->execute([$m_num]);
	$no=$stmt->rowCount();  
	while($row=$stmt->fetch()){
?>
				<li><a href="#" ><span class="l"></span><span class="r"></span>
				<span class="t"><?=$row["s_username"];?></span>
				<span class="x" style="display:none;"><?=$row["s_num"];?></span>
					</a>
				</li> 
<?
}
?>		
			</ul>
			</div>
			<div class="form-group form-inline">
				<label for="username">商品成本：</label>
				<input type="text" name="pcost" class="form-control col-sm-3" id="pcost" placeholder="輸入商品成本">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">單價：</label>
				<input type="text" name="pprice" class="form-control col-sm-3" id="pprice" placeholder="輸入單價">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">庫存：</label>
				<input type="text" name="pstock"  class="form-control col-sm-3" id="pstock" placeholder="輸入庫存數量">
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" class="btn btn-outline-secondary" type="hidden" id="action" value="add">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="送出">
            <input type="reset"  class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>

<script>
$(document).ready(function() 
 {
 $("#div1").hide();
 
$("#snum").click(function(){
  $("#div1").fadeToggle();
});

    $('ul.art-vmenu li').click(function(e) 
    { 
	 var xxx=$(this).find("span.t").text();
	 var xxxx=$(this).find("span.x").text();
	 $("#snum").val(xxx);
	 $("#snumx").val(xxxx);
    });
 });
</script>