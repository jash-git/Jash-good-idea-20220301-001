<?
require_once("db.php");

function GetSQLValueString($theValue, $theType) {
  switch ($theType) {
    case "string":
      $theValue = ($theValue != "") ? filter_var($theValue, FILTER_SANITIZE_ADD_SLASHES) : "";
      break;
    case "int":
      $theValue = ($theValue != "") ? filter_var($theValue, FILTER_SANITIZE_NUMBER_INT) : "";
      break;
    case "email":
      $theValue = ($theValue != "") ? filter_var($theValue, FILTER_VALIDATE_EMAIL) : "";
      break;
    case "url":
      $theValue = ($theValue != "") ? filter_var($theValue, FILTER_VALIDATE_URL) : "";
      break;      
  }
  return $theValue;
}

$usereid=$_POST["usereid"];
$userpasswd=$_POST["userpasswd"];
$comname=$_POST["comname"];
$comtel=$_POST["comtel"];
$comphone=$_POST["comphone"];
$email=$_POST["email"];
$puser=$_POST["puser"];
if(isset($_POST["usereid"])&& $_POST["userpasswd"] && $_POST["comname"]&&$_POST["comtel"]&&$_POST["comphone"]&&$_POST["email"]&&$_POST["puser"])
echo "";
else
header("Location: index.php?a=member_add&errMsg=1");
//---------
if(isset($_POST["action"])&&($_POST["action"]=="join")){
	//找尋帳號是否已經註冊
	$m_numx = $_POST["c_id"];

	$stmt = $db_link->prepare("SELECT count(m_num) FROM memberx WHERE m_num=? and m_id=?");
	$stmt->execute([$m_numx,$_POST["usereid"]]);
	$no=$stmt->rowCount();  
	$row=$stmt->fetch();
	//echo $row["m_num"];
	//$row=$stmt->fetch();
	//$rowCount = $stmt->fetchColumn(); 
	echo $no;
	if ($no>1){
		echo "已有資料";
		//echo $m_num;
		header("Location: index.php?a=member_add&errMsg=2");
	}else{
		echo "可以新增";
		//若沒有執行新增的動作	
		//$sql = "INSERT INTO memberx (m_num) VALUES (?)";
		//$db_link->prepare($sql)->execute(['a']);
		
		
		try {
		//$query_insert = "INSERT INTO memberx (m_id, m_pwd, m_username, m_num, m_tel, m_phone, m_adr, m_mail, m_pname, m_jointime, m_logintime, m_login, m_power) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";
		$query_insert = "INSERT INTO memberx (m_id, m_pwd, m_username, m_num, m_tel, m_phone, m_adr, m_mail, m_pname, m_jointime, m_logintime, m_login, m_power) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(),NOW(),0,0)";
		
		$stmt = $db_link->prepare($query_insert);
		$date = date('Y-m-d H:i:s');
		$m_id=GetSQLValueString($_POST["usereid"], 'string');
		$m_pwd=GetSQLValueString($_POST["userpasswd"], 'string');
		$m_username=GetSQLValueString($_POST["comname"], 'string');
		$m_num=GetSQLValueString($_POST["c_id"], 'string');//廠商編號
		$m_tel=GetSQLValueString($_POST["comtel"], 'string');
		$m_phone=GetSQLValueString($_POST["comphone"], 'string');
		$m_adr=GetSQLValueString($_POST["comaddr"], 'string');
		$m_mail=GetSQLValueString($_POST["email"], 'email');
		$m_pname=GetSQLValueString($_POST["puser"], 'string');
		//$m_jointime=GetSQLValueString($date, 'string');
		//$m_logintime=GetSQLValueString($date, 'string');
		//$m_login="0";
		//$m_power="0";
		//$stmt->execute(array($m_id, $m_pwd,$m_username,$m_num,$m_tel,$m_phone,$m_adr,$m_mail,$m_pname,$m_jointime,$m_logintime,$m_login,$m_power));		
		$stmt->execute([$m_id, $m_pwd,$m_username,$m_num,$m_tel,$m_phone,$m_adr,$m_mail,$m_pname]);
		header("Location: index.php?a=member_add&registStats=1");	
		}catch (PDOException $ex) {
			error($ex);
		}

		
		
		/*
		//$stmt->bind_param("sssssssss", 
			GetSQLValueString($_POST["usereid"], 'string'),
			GetSQLValueString($_POST["userpasswd"], 'string'),
			GetSQLValueString($_POST["comname"], 'string'),
			//password_hash($_POST["m_passwd"], PASSWORD_DEFAULT),
			GetSQLValueString($_POST["c_id"], 'string'),//廠商編號
			GetSQLValueString($_POST["comtel"], 'string'),
			GetSQLValueString($_POST["comphone"], 'string'),
			GetSQLValueString($_POST["comaddr"], 'string'),
			GetSQLValueString($_POST["email"], 'email'),
			GetSQLValueString($_POST["puser"], 'string'));
		$stmt->execute();
		$stmt->close();
		$db_link->close();
		//header("Location: member_join.php?loginStats=1");
		*/
	}
}
/*
if(isset($_POST["action"])&&($_POST["action"]=="join")){
	echo "1";
	//require_once("connMysql.php");
	//找尋帳號是否已經註冊
	$m_num = $_POST["m_num"];	
	$stmt = $db_link->prepare("SELECT count(*) FROM member WHERE m_num=?");
	$stmt->execute([$m_num]);
	//$row=$stmt->fetch();
	$rowCount = $stmt->fetchColumn(); 
	if ($rowCount>0){
		echo "已有資料";
		//header("Location: index.php?errMsg=1&username={$_POST["m_username"]}");
	}else{
		echo "可以新增";
	}
	*/
	//$stmt = $db_link->prepare("SELECT * FROM students WHERE cSex = ? AND cID <= ?");
	/*if($stmt->execute(array($m_num))){
		while($row=$stmt->fetch()){
			echo "座號：{$row['cID']}<br>姓名：{$row['cName']}<br>電子郵件：{$row['cEmail']}<br>電話：{$row['cPhone']}<hr>";
		}
	}*/
	//-----------
	/*
	$query_RecFindUser = "SELECT m_id FROM member WHERE m_num='{$_POST["m_num"]}'";
	$RecFindUser=$db_link->query($query_RecFindUser);
	if ($RecFindUser->num_rows>0){
		echo "已有資料";
		//header("Location: index.php?errMsg=1&username={$_POST["m_username"]}");
	}else{
	//若沒有執行新增的動作	
		$query_insert = "INSERT INTO memberdata (m_name, m_username, m_passwd, m_sex, m_birthday, m_email, m_url, m_phone, m_address, m_jointime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
		$stmt = $db_link->prepare($query_insert);
		$stmt->bind_param("sssssssss", 
			GetSQLValueString($_POST["m_name"], 'string'),
			GetSQLValueString($_POST["m_username"], 'string'),
			password_hash($_POST["m_passwd"], PASSWORD_DEFAULT),
			GetSQLValueString($_POST["m_sex"], 'string'),
			GetSQLValueString($_POST["m_birthday"], 'string'),
			GetSQLValueString($_POST["m_email"], 'email'),
			GetSQLValueString($_POST["m_url"], 'url'),
			GetSQLValueString($_POST["m_phone"], 'string'),
			GetSQLValueString($_POST["m_address"], 'string'));
		$stmt->execute();
		$stmt->close();
		$db_link->close();
		header("Location: member_join.php?loginStats=1");
	}*/
	/*
}else
{
	echo $_POST["action"];
	echo "2";
}*/
?>