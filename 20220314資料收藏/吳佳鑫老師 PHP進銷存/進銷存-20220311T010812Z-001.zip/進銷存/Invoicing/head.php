<?
//執行登出動作
if(isset($_GET["logout"]) && ($_GET["logout"]=="true")){
	unset($_SESSION["loginMember"]);
	unset($_SESSION["memberLevel"]);
	header("Location: index.php");
}
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<title>進銷存系統</title>
	<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
<header class="header_bg navbar-fixed-top">
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="index.php">
			<img alt="Logo" src="images/logo.png" width="80px">
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav">
			<!--
				<li class="nav-item active">
					<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
				</li>
-->
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
					 aria-haspopup="true" aria-expanded="false">
						基本資料
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="index.php?a=supplier_list">供應商</a>
						<a class="dropdown-item" href="index.php?a=customer_list">客戶</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="index.php?a=product_list">產品</a>
						<!--<a class="dropdown-item" href="#">業務員</a>-->
					</div>
				</li>
				
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
					 aria-haspopup="true" aria-expanded="false">
						進銷作業
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="index.php?a=purchase_list">進貨作業</a>
						<a class="dropdown-item" href="index.php?a=sales_list">銷貨作業</a>
					</div>
				</li>
<?
 if($level==1)
 {
?>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
					 aria-haspopup="true" aria-expanded="false">
						系統管理
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="index.php?a=member_center">會員管理</a>
						<a class="dropdown-item" href="#"></a>
					</div>
				</li>
<?
 }
?>
<?
$stmt = $db_link->prepare("SELECT * FROM memberx WHERE m_num=?");
	$stmt->execute([$m_num]);
	$no=$stmt->rowCount();  
	$row=$stmt->fetch();
if($m_num!="")
{
?>
				<li class="nav-item active">
					<a class="nav-link" href="#">歡迎&nbsp 使用者：<?=$row["m_username"];?> | <?=$row["m_pname"];?>  | 登入時間：<?=$row["m_logintime"];?><span class="sr-only">(current)</span></a>
				</li>
<?
}
?>
<?
if($m_num!="")
{
?>
				<li class="nav-item active">
					<a class="nav-link" href="?logout=true">登出<span class="sr-only">(current)</span></a>
				</li>
<?
}
?>
			</ul>
		</div>
	</nav>
</header>