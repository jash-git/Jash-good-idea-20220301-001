<?
require_once("db.php");

$data = [$_POST["usereid"],
		$_POST["userpasswd"],
		$_POST["comname"],
		$_POST["comtel"],
		$_POST["comphone"],
		$_POST["comaddr"],
		$_POST["email"],
		$_POST["puser"],
		$_POST["power"],
		$_POST["c_id"]
		];
/*$data = [$_POST["usereid"],
		$_POST["c_id"]
		];
*/
$query_RecLoginUpdate = "UPDATE memberx SET m_id=? , m_pwd=? , m_username=? , m_tel=? , m_phone=? , m_adr=? , m_mail=? , m_pname=? , m_power=?  WHERE m_num=?";
//$query_RecLoginUpdate = "UPDATE memberx SET m_id=?  WHERE m_num=?";

$stmt=$db_link->prepare($query_RecLoginUpdate);
$stmt->execute($data);
header("Location: index.php?a=member_view&c_id=".$_POST["c_id"]);	
?>