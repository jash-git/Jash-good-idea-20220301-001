<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}

    .box {
        //width: 100vw;
        //height: auto;
        position: absolute;
        font-family: "微軟正黑體";
        //margin: 50px;
		top: 20vh; 
		left: 10vw;
        text-align: center;
    }
	.box2 {
        position: absolute;
        font-family: "微軟正黑體";
    	top: 20vh; 
		left: 10vw;
        text-align: center;
    }
    .service {
        width: 80vw;
        //height: 100px;
        position: relative;
        background: lightblue;
        cursor: default;
    }
    .service p {
        //line-height: 100px;
    }
	
	.service2 {
        width: 80vw;
        position: relative;
        background: lightblue;
        cursor: default;
    }
.navFixed {
  z-index: 99;
  top: 5vh;  
  left: -5vw;
  position: fixed;      
}
</style>
	<div class="container">
		<h3>修改-銷貨單</h3>
		<form id="form" action="ss_update.php" method="post">
<?
	$ss_id=$_GET["ss_id"];
	$stmt = $db_link->prepare("SELECT * FROM sales WHERE m_num=? and ss_num=?");
	$stmt->execute([$m_num,$ss_id]);
	$row=$stmt->fetch();
?>
		<input name="ss_id" type="hidden" value="<?=$ss_id;?>">

			<div class="form-group form-inline">
				<label for="ssnum">訂單編號：</label>
				<input type="text" name="ssnum" class="form-control col-sm-3" id="ssnum" placeholder="輸入銷貨單號" value="<?=$row["ss_snum"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="pname">客戶名稱：</label>
<?
$scnum=$row["sc_num"];
$stmt2 = $db_link->prepare("SELECT * FROM  customer WHERE m_num=? and c_num=?");
$stmt2->execute([$m_num,$scnum]);
$row2=$stmt2->fetch();
?>
				<input type="text" name="pname" class="form-control col-sm-3" id="pname" placeholder="輸入客戶名稱" value="<?=$row2["c_username"];?>">
				<input type="hidden" name="scnum" class="form-control col-sm-3" id="scnum" value="<?=$row2["c_num"];?>">
				<a href="#" id="pnamex">選擇客戶</a>
			</div>
			<div class="form-group form-inline">
				<label for="ssnum">訂單日期：</label>
				<?=$row["s_date"];?>
			</div>
			<div class="form-group form-inline">
				<label for="ssnum">物流單號：</label>
				<input type="text" name="ssonum" class="form-control col-sm-3" id="ssonum" placeholder="輸入物流單號">
			</div>
<!-- -->			
<div class="box">
    <div class="service">
        <p id="pselection">
<?
	$stmt3 = $db_link->prepare("SELECT * FROM  customer where m_num=?");//一般使用者
	$stmt3->execute([$m_num]);
	while($row3=$stmt3->fetch()){
?>
		<a href="#"><span class="t"><?=$row3["c_username"];?></span>
		<span class="x" style="display:none;"><?=$row3["c_num"];?></span></a>
<?
}
?>
		</p>
    </div>
</div>
<!-- -->
<nav class="go">
<div class="box2">
    <div class="service2">
        <p id="spselection">
<?
	$stmt4 = $db_link->prepare("SELECT * FROM  product where m_num=?");//一般使用者
	$stmt4->execute([$m_num]);
	while($row4=$stmt4->fetch()){
?>
		<a href="#"><span class="t"><?=$row4["p_name"];?></span>
		<span class="x" style="display:none;"><?=$row4["p_num"];?></span>
		<span class="y" style="display:none;"><?=$row4["p_price"];?></span>
		<span class="z" style="display:none;"><?=$row4["p_cost"];?></span>
		</a> ||
<?
}
?>
		</p>
    </div>
</div>
</nav>
<!-- -->
<hr>
<!-- -->
	<div class="container">
		<div class="row">
			<div class="col">
				<h3>銷貨明細</h3> 
				<p style="text-align:right;"><a href="#" class="add_button">新增產品</a></p>	
				<table class="table">
					<thead>
						<tr>
							<th>商品名稱</th>
							<th>單價</th>
							<th>成本</th>
							<th>數量</th>
						</tr>
					</thead>
					<tbody class="input_fields_wrap">
<?
$i="";
$stmt5 = $db_link->prepare("SELECT * FROM Sales_product where so_num=?");//一般使用者
$stmt5->execute([$ss_id]);
while($row5=$stmt5->fetch()){
$spnum=$row5["sp_num"];
	$stmt44 = $db_link->prepare("SELECT * FROM  product where m_num=? and p_num=?");//一般使用者
	$stmt44->execute([$m_num,$spnum]);
	$row44=$stmt44->fetch()
?>
						<tr>
							<td><input type="text" name="spname" class="form-control " id="spname<?=$i;?>" placeholder="選擇商品名稱" value="<?=$row44["p_name"];?>">
							<input type="hidden" name="spnum[]" class="form-control " id="spnum<?=$i;?>" value="<?=$row5["sp_num"];?>">
							<!--<a href="#" id="Sel_product">選擇商品</a> 2021.10.07 修正為欄位選取-->
							</td>
							<td><input type="text" name="sprice[]" class="form-control " id="sprice<?=$i;?>" placeholder="輸入商品單價" value="<?=$row5["s_price"];?>"></td>
							<td><input type="text" name="pcost[]" class="form-control " id="pcost<?=$i;?>" placeholder="輸入商品成本" value="<?=$row5["s_cost"];?>"></td>
							<td><input type="text" name="puquantity[]"  class="form-control " id="puquantity" placeholder="輸入數量" value="<?=$row5["s_quantity"];?>">	
							<input type="hidden" name="ppid[]"  class="form-control " value="<?=$row5["pp_id"];?>">	
							</td>
						</tr>
<?
$i++;
}
?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- -->
<hr>

			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"><?=$row["ss_memo"];?></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="add">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="送出">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
	</div>
		</form>
<script>
var x = 0;
var axx = 0;
$(document).ready(function() 
 {
	  $(".service").hide();
	  $(".service2").hide();
	  x=<?=$i;?>;
	  //console.log(x);
//點擊商品選擇欄位
$("#spname").click(function () {
	$(".service2").fadeToggle();
    axx=0;
	//x=0;
	//console.log(axx);
});

	//這個功能是點擊含有 close class 的元素之後"隱藏/顯示"含有 service class 的元素
        //選擇客戶名稱
		$("#pnamex").click(function () {
            $(".service").fadeToggle();
        });
		
		//選擇商品名稱
		//$("#spname").click(function () {
		$("#Sel_product").on("click", function(e){
            $(".service2").fadeToggle();
        });
		
	//選擇客戶名稱 點擊給值
	$('#pselection').click(function(e) 
    { 
	 var xxx=$(this).find("span.t").text();
	 var xxxx=$(this).find("span.x").text();
	 $("#pname").val(xxx);
	 $("#scnum").val(xxxx);
    });
	
	//選擇商品名稱 點擊給值
	$('#spselection a').click(function(e) 
    {
		//alert(e.target.id);
	 var xx=$(this).find("span.t").text();//商品名
	 var xxx=$(this).find("span.x").text();//商品代號
	 var xxxx=$(this).find("span.y").text();//單價
	 var xxxxx=$(this).find("span.z").text();//成本
	 
	 if(axx<1)
	 {
	  $("#spname").val(xx);
	  $("#spnum").val(xxx);
	  $("#sprice").val(xxxx);
	  $("#pcost").val(xxxxx);
	 }
	 else
	 {
	  $("#spname"+axx).val(xx);
	  $("#spnum"+axx).val(xxx);
	  $("#sprice"+axx).val(xxxx);
	  $("#pcost"+axx).val(xxxxx);
	 }
    });

	//-----
	//動態欄位
	var max_fields      = 10; //maximum input boxes allowed
	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
	var add_button      = $(".add_button"); //Add button ID
	
	//x = 1; //initlal text box count
	$(add_button).click(function(e){ //on add input button click
		e.preventDefault();
		if(x < max_fields){ //max input box allowed
			x++; //text box increment
			$(wrapper).append(
			'<tr>'+
			'<td><input type="text" name="spname" class="form-control " id="spname'+
			x+
			'" placeholder="選擇商品名稱">'+
			'<input type="hidden" name="spnum[]" class="form-control " id="spnum'+
			x+
			'">'+
			//'<a href="#" class="Sel_product">選擇商品</a>'+
			'</td>'+
			'<td><input type="text" name="sprice[]" class="form-control " id="sprice'+
			x+
			'" placeholder="輸入商品單價"></td>'+
			'<td><input type="text" name="pcost[]" class="form-control " id="pcost'+
			x+
			'" placeholder="輸入商品成本"></td>'+
			'<td><input type="text" name="puquantity[]"  class="form-control " id="puquantity" placeholder="輸入數量">'+		
			'<a href="#" class="remove_field">刪除</a></td>'+
			'</tr>'); //add input box
			
		}
	});
	//-----
	
	$(document).on("click","#spname1",function () {
	 $(".service2").fadeToggle();
     axx=1;
	 console.log("#spname1="+axx);
	});
	
	$(document).on("click","#spname2",function () {
	 $(".service2").fadeToggle();
     axx=2;
	 console.log(axx);
	});
	
	$(document).on("click","#spname3",function () {
	 $(".service2").fadeToggle();
     axx=3;
	 console.log(axx);
	});
	
	$(document).on("click","#spname4",function () {
	 $(".service2").fadeToggle();
     axx=4;
	 console.log(axx);
	});
	
	$(document).on("click","#spname5",function () {
	 $(".service5").fadeToggle();
     axx=5;
	 console.log(axx);
	});
	
	$(document).on("click","#spname6",function () {
	 $(".service2").fadeToggle();
     axx=6;
	 console.log(axx);
	});
	
	$(document).on("click","#spname7",function () {
	 $(".service2").fadeToggle();
     axx=7;
	 console.log(axx);
	});
	
	$(document).on("click","#spname8",function () {
	 $(".service2").fadeToggle();
     axx=8;
	 console.log(axx);
	});
	
	$(document).on("click","#spname9",function () {
	 $(".service2").fadeToggle();
     axx=9;
	 console.log(axx);
	});
	
	$(document).on("click","#spname10",function () {
	 $(".service2").fadeToggle();
     axx=10;
	 console.log(axx);
	});	
//-----
	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		e.preventDefault(); 
		//$(this).parent('tr').remove(); 
		$(this).closest("tr").remove();
		x--;
	})
	
	$(wrapper).on("click",".Sel_product", function(e){ //user click on remove text
		e.preventDefault(); 
		$(".service2").fadeToggle();
		//$(this).parent('tr').remove(); 
		//$(this).closest("tr").remove();
		//x--;
	})
	//浮動視窗
	 $(window).scroll(function() {
    if ($(this).scrollTop() > 50)  {          /* 要滑動到選單的距離 */
       $('.go').addClass('navFixed');   /* 幫選單加上固定效果 */
	   //console.log("123");
    } else {
      $('.go').removeClass('navFixed'); /* 移除選單固定效果 */
    }
  });
	//-----
 });

</script>