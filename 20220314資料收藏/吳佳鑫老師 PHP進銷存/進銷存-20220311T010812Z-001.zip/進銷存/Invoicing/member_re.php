<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>修改會員資料</h3>
		<form id="form" action="member_update.php" method="post">
		<!-- 廠商編號 -->
<?
	$c_id=$_GET["c_id"];
	$stmt = $db_link->prepare("SELECT * FROM memberx WHERE m_num=?");
	$stmt->execute([$c_id]);
	$row=$stmt->fetch();
?>
		<input name="c_id" type="hidden" value="<?=$c_id;?>">

			<div class="form-group form-inline">
				<label for="usereid">帳號：</label>
				<input type="text" name="usereid" class="form-control col-sm-3" id="usereid" placeholder="輸入帳號" value="<?=$row["m_id"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">密碼：</label>
				<input type="password" name="userpasswd" class="form-control col-sm-3" id="userpasswd" placeholder="輸入密碼" value="<?=$row["m_pwd"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="passwdrecheck">確認密碼：</label>
				<input type="password" name="passwdrecheck" class="form-control col-sm-3" id="passwdrecheck" placeholder="請確認輸入密碼" value="<?=$row["m_pwd"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">公司名稱：</label>
				<input type="text" name="comname" class="form-control col-sm-3" id="comname" placeholder="輸入公司名稱" value="<?=$row["m_username"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<input type="text" name="comtel" class="form-control col-sm-3" id="comtel" placeholder="輸入電話號碼" value="<?=$row["m_tel"];?>">
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<input type="text" name="comphone"  class="form-control col-sm-3" id="comphone" placeholder="輸入行動電話" value="<?=$row["m_phone"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<input type="text" name="comaddr" class="form-control col-sm-3" id="comaddr" placeholder="輸入住址" value="<?=$row["m_adr"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<input type="text" name="email" class="form-control col-sm-3" id="email" placeholder="輸入E-Mail" value="<?=$row["m_mail"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人：</label>
				<input type="text" name="puser" class="form-control col-sm-3" id="puser" placeholder="輸入聯絡人姓名" value="<?=$row["m_pname"];?>">
			</div>
			<div class="form-group form-inline">
				<label for="username">權限：</label>
				<input type="text" name="power" class="form-control col-sm-3" id="power" placeholder="輸入權限" value="<?=$row["m_power"];?>">
			</div>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="join">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="修改">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		  <!--
			<button type="submit" class="btn btn-default">送出</button>
			<button type="button" class="btn btn-default" onClick="history.back();">回上一頁</button>
		-->
		</form>
	</div>
<script>
$(function(){
        $('#form').validate({
       onkeyup: function(element, event) {
         //去除左側空白
		 /*
		 console.log(str.replace(/\s/g, '#'));                                // ##A#B##C###D#EF#
		 console.log(str.replace(/\s+/g, '#'));                             // #A#B#C#D#EF#  --> 代表1到多個
		 */
         var value = this.elementValue(element).replace(/^\s+/g, "");// ^表示匹配 \s 一個字串，s+表示許多 g表示全部匹配
         $(element).val(value);
        },
        rules: {
            /*
                required:必填
                noSpace:空白
                minlength:最小長度
                maxlength:最大長度
                email:信箱格式
                number:數字格式
                url:網址格式https://www.google.com
            */
          usereid: {
            required: true,
            noSpace: true
          },
		  userpasswd: {
            required: true,
            noSpace: true
          },
		  comname: {
            required: true,
            noSpace: true
          },
          comtel:{
            required: true,
            minlength: 8,
            number: true
          },
          comaddr: 'required',
          //url:{
          //  url: true
          //},
          email: {
            required: true,
            email: true
          }
        },
        messages: {
          fname: {
            required:'必填',
            noSpace: '不可有空白'
          },
          phone: {
            required:'必填',
            minlength:'不得少於8位',
            number:'電話需為數字'
          },
          address: '必填',
          email: {
            required: '必填',
            email: 'Email格式不正確'
          },
          url: '網址格式不正確'
        },
        submitHandler: function(form) {
          form.submit();
        }
  });
});
</script>
	