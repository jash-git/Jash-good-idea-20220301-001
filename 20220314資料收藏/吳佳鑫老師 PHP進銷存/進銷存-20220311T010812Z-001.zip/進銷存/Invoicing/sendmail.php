<?
require_once("db.php");

//函式：自動產生指定長度的密碼
function MakePass($length) { 
	$possible = "0123456789!@#$%^&*()_+abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
	$str = ""; 
	while(strlen($str)<$length){ 
	  $str .= substr($possible, rand(0, strlen($possible)), 1); 
	}
	return($str); 
}
//-----------------------------------寄發 密碼 mail Start member_forget
switch($mailsend)
{
	case "mailforget": //忘記密碼
		//產生新密碼並更新
		$newpasswd = MakePass(10);
	
$data = [$newpasswd,
		 $m_num
		];	
		
		$query_RecLoginUpdate = "UPDATE memberx SET m_pwd=? WHERE m_num=?";
		$stmt=$db_link->prepare($query_RecLoginUpdate);
		$stmt->execute($data);

		//補寄密碼信
		$mailcontent ="您好，<br />您的帳號為：{$m_id} <br/>您的新密碼為：{$newpasswd} <br/>";
		$mailFrom="=?UTF-8?B?" . base64_encode("會員管理系統") . "?= <20210522.cc@gmail.com.tw>";
		//$mailto=$usermail;
		$mailSubject="=?UTF-8?B?" . base64_encode("補寄密碼信"). "?=";
		$mailHeader="From:".$mailFrom."\r\n";
		$mailHeader.="Content-type:text/html;charset=UTF-8";
		if(!@mail($mailto,$mailSubject,$mailcontent,$mailHeader)) die("郵寄失敗！");
		header("Location: index.php?a=member_forget&mailStats=1");
//-----------------------------------寄發 密碼 mail END
	break;
//-----------------------------------寄發 出貨通知信 sales_view & sales_oqc
	case "notify": //出貨通知信
//郵寄通知
	$stmt8 = $db_link->prepare("SELECT * FROM Sales where m_num=? and ss_num=? ");//一般使用者
	$stmt8->execute([$m_num,$ss_id]);
	$row8=$stmt8->fetch();
	$ssnum=$row8["ss_snum"];//訂單編號
	
	$scnum=$row8["sc_num"];//客戶編號
	$stmt88 = $db_link->prepare("SELECT * FROM  customer where m_num=? and c_num=? ");//一般使用者
	$stmt88->execute([$m_num,$scnum]);
	$row88=$stmt88->fetch();
	$cname=$row88["c_username"];//客戶名稱
	$cpname=$row88["c_pname"];//聯絡人
	$caddress=$row88["c_addr"];//地址
	$cmail=$row88["c_mail"];//email
	$cpcode=$row88["c_pcode"];//郵遞區號
	$ctel=$row88["c_tel"];//電話：
	$cphone=$row88["c_phone"];//手機
	
	//$ssonum//物流單號
	$sodate=$row8["s_odate"];//出貨日期
	$ssmemo=$row8["ss_memo"];//備註

	$mailcontent=<<<HTML
	親愛的 $cname / $cpname 您好：</br>
	感謝您的光臨</br>
	本次消費詳細資料如下：</br>
<hr>
	訂單編號： $ssnum </br>
	物流單號： $ssonum </br>
	客戶姓名：$cname / $cpname </br>
	電子郵件： $cmail </br>
	電話： $ctel || 手機： $ctel </br>
	住址： $cpcode  $caddress </br>
	備註： $ssmemo </br>
<hr>
<h3>銷貨明細</h3>
				<table>
					<tr>
						<td>商品名稱</td>
						<td>單價</td>
						<td>數量</td>
						<td>小計</td>
					</tr>
HTML;

$stmt3 = $db_link->prepare("SELECT * FROM Sales_product where so_num=? ");//一般使用者
$stmt3->execute([$ss_id]);
while($row3=$stmt3->fetch()){
	
$mailcontent.=<<<HTML
					<tr>
						<td>
HTML;

$pnum=$row3["sp_num"];
$stmt33 = $db_link->prepare("SELECT * FROM product where m_num=? and p_num=? ");//一般使用者
$stmt33->execute([$m_num,$pnum]);
$row33=$stmt33->fetch();
$mailcontent .= $row33["p_name"];

$mailcontent .=<<<HTML
						</td>
						<td>$ 
HTML;

$mailcontent .= $row3["s_price"];
$mailcontent .=<<<HTML
						</td>
						<td>
HTML;

$mailcontent .= $row3["s_quantity"];
$mailcontent .=<<<HTML
						</td>
						<td>$
HTML;

$mailcontent .= $mtotla=$row3["s_price"]*$row3["s_quantity"];

$mailcontent .=<<<HTML
						</td>
					</tr>
HTML;
}

$mailcontent .=<<<HTML
					<tr>
						<td></td>
						<td></td>
						<td>訂單總計:</td>
						<td>$
HTML;
	$stmt4 = $db_link->prepare("SELECT *, SUM(s_quantity*s_price) as mtotal,SUM(s_quantity*s_cost) as stotal FROM Sales_product where so_num=? ");//一般使用者
	$stmt4->execute([$ss_id]);
	$row4=$stmt4->fetch();
$mailcontent .=$row4["mtotal"];
$mailcontent .=<<<HTML
						</td>
					</tr>
				</table>
<hr>	
	希望能再次為您服務 </br>
	
	網路購物公司 敬上</br>
HTML;

	$mailFrom="=?UTF-8?B?" . base64_encode("網路購物系統") . "?= <20210210.cc@gmail.com>";
	$mailto = $cmail;
	$mailSubject="=?UTF-8?B?" . base64_encode("網路購物系統訂單通知"). "?=";
	$mailHeader="From:".$mailFrom."\r\n";
	$mailHeader.="Content-type:text/html;charset=UTF-8";
	if(!@mail($mailto,$mailSubject,nl2br($mailcontent),$mailHeader)) die("郵寄失敗！");
	break;
}
?>