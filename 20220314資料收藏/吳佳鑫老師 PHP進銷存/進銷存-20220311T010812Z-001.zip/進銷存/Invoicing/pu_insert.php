<?
session_start();
require_once("db.php");

$m_num = $_SESSION["loginMember"];

if(isset($_POST["action"])&&($_POST["action"]=="add")){

		echo "可以新增";
		$date = date('Y-m-d H:i:s');
		
		//進貨單 表頭資料寫入
		$data=[$m_num, //廠商代號
		$_POST["pu_id"], //進貨代號 唯一值
		$_POST["punum"], //進貨單號 (使用者KEYIN)
		$date, //進貨日期
		$_POST["memo"]//備註
		];
		$query_insert = "INSERT INTO purchase (m_num, pu_num, pu_snum,pu_date,pu_memo) VALUES (?, ?, ?, ?, ?)";
		$stmt = $db_link->prepare($query_insert);
		$stmt->execute($data);
		
		//進貨單 明細資料寫入
		
		$xn = count($_POST["pname"]); //取得資料筆數
		echo $xn;
		//echo $_POST["pname"][1]; //商品名稱
		for($i=0;$i<$xn;$i++)
		{
		 $data[$i]=[$_POST["pu_id"], //進貨代號 唯一值
		 $_POST["pnum"][$i], //商品代號
		 $_POST["puquantity"][$i], // 數量
		 $_POST["pcost"][$i], // 商品成本
		 $_POST["snum"][$i], // 供應商
		 ];
		 $query_insert = "INSERT INTO purchase_product (pu_num, ps_num, pu_quantity,p_cost, s_num) VALUES (?, ?, ?, ?, ?)";
		 $stmt = $db_link->prepare($query_insert);
		 $stmt->execute($data[$i]);
		}
		header("Location: index.php?a=purchase_list");	
//	print_r($data);

}

?>