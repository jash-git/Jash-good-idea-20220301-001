<?
$cmdx="";//第二層
$cmdxx="";//第三層
switch($cmd)
{
//-----------會員 member
 case "member_add": //會員註冊-申請-新增
 $cmdx="會員註冊-申請";
 $cmdxx="";
 break;
 
 case "member_center": //進入後台 (管理者)
 $cmdx="會員管理列表";
 $cmdxx="";
 break;

 case "member_re": //進入後台 (管理者)-修改 3
 $cmdx="會員管理列表"; 
 $cmdxx="修改會員"; 
 break;
 
 case "member_del": //進入後台 (管理者)-刪除
 $cmdx="會員管理列表"; 
 $cmdxx="刪除會員"; 
 break; 
 
 case "member_view": //進入後台 (管理者)-查看
 $cmdx="會員管理列表"; 
 $cmdxx="查看會員"; 
 break; 
 
 case "member_forget": //會員註冊-忘記密碼
 $cmdx="會員-忘記密碼"; 
 $cmdxx=""; 
 break;

//-----------供應商 supplier
 case "supplier_add": //供應商-新增
 $cmdx="供應商列表"; 
 $cmdxx="新增供應商"; 
 break;
 
 case "supplier_list": //進入後台 (管理者)
 $cmdx="供應商列表"; 
 $cmdxx=""; 
 break;

 case "supplier_re": //進入後台 (管理者)-修改
 $cmdx="供應商列表"; 
 $cmdxx="修改供應商"; 
 break;
 
 case "supplier_del": //進入後台 (管理者)-刪除
 $cmdx="供應商列表"; 
 $cmdxx="刪除供應商"; 
 break; 
 
 case "supplier_view": //進入後台 (管理者)-查看
 $cmdx="供應商列表"; 
 $cmdxx="查看供應商"; 
 break; 
 
//-----------客戶 customer
 case "customer_add": //客戶-申請-新增
 $cmdx="客戶列表"; 
 $cmdxx="新增客戶"; 
 break;
 
 case "customer_list": //進入後台 (管理者)
 $cmdx="客戶列表"; 
 $cmdxx=""; 
 break;

 case "customer_re": //進入後台 (管理者)-修改
 $cmdx="客戶列表"; 
 $cmdxx="修改客戶"; 
 break;
 
 case "customer_del": //進入後台 (管理者)-刪除
 $cmdx="客戶列表"; 
 $cmdxx="刪除客戶"; 
 break; 
 
 case "customer_view": //進入後台 (管理者)-查看
 $cmdx="客戶列表"; 
 $cmdxx="查看客戶";
 break; 
 //-----------產品 product
 case "product_add": //產品-新增
 $cmdx="產品列表"; 
 $cmdxx="新增產品"; 
 break;
 
 case "product_list": //進入後台 (管理者)
 $cmdx="產品列表"; 
 $cmdxx=""; 
 break;

 case "product_re": //進入後台 (管理者)-修改
 $cmdx="產品列表"; 
 $cmdxx="修改產品"; 
 break;
 
 case "product_del": //進入後台 (管理者)-刪除
 $cmdx="產品列表"; 
 $cmdxx="刪除產品"; 
 break; 
 
 case "product_view": //進入後台 (管理者)-查看
 $cmdx="產品列表"; 
 $cmdxx="查看產品"; 
 break; 
 
 //-----------進貨作業 purchase
 case "purchase_add": //進貨單-新增
 $cmdx="進貨單列表"; 
 $cmdxx="新增進貨單"; 
 break;
 
 case "purchase_list": //進入後台 (管理者)
 $cmdx="進貨單列表"; 
 $cmdxx=""; 
 break;

 case "purchase_re": //進入後台 (管理者)-修改
 $cmdx="進貨單列表"; 
 $cmdxx="修改進貨單"; 
 break;
 
 case "purchase_del": //進入後台 (管理者)-刪除
 $cmdx="進貨單列表"; 
 $cmdxx="刪除進貨單"; 
 break; 
 
 case "purchase_view": //進入後台 (管理者)-查看
 $cmdx="進貨單列表"; 
 $cmdxx="查看進貨單"; 
 break; 
 
 case "purchase_iqc": //進入後台 (管理者)-入庫
 $cmdx="進貨單列表"; 
 $cmdxx="查看&入庫"; 
 break; 
 //-----------銷貨作業 sales
 case "sales_add": //進貨單-新增
 $cmdx="銷貨單列表"; 
 $cmdxx="新增銷貨單"; 
 break;
 
 case "sales_list": //進入後台 (管理者)
 $cmdx="銷貨單列表";
 $cmdxx=""; 
 break;

 case "sales_re": //進入後台 (管理者)-修改
 $cmdx="銷貨單列表";
 $cmdxx="修改銷貨單"; 
 break;
 
 case "sales_del": //進入後台 (管理者)-刪除
 $cmdx="銷貨單列表";
 $cmdxx="刪除銷貨單"; 
 break; 
 
 case "sales_view": //進入後台 (管理者)-查看 出貨
 $cmdx="銷貨單列表";
 $cmdxx="查看銷貨單"; 
 break; 
 
 case "sales_oqc": //進入後台 (管理者)-出貨
 $cmdx="銷貨單列表";
 $cmdxx="查看&出貨"; 
 break; 
//-----------
 default:
 $cmdx="";
 $cmdxx=""; 
}
?>
		<nav>
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.php">首頁</a></li>
<?
if($cmdx!="")
{
?>
				<li class="breadcrumb-item"><a href="javascript:history.back()"><?=$cmdx;?></a></li>
<?
}
?>
<?
if($cmdxx!="")
{
?>
				<li class="breadcrumb-item active"><?=$cmdxx;?></li>
<?
}
?>
			</ol>
		</nav>
