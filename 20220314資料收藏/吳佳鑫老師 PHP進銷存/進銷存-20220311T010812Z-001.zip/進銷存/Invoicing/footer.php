<!-- Footer -->	
<footer class="container">
<center>
<div class="footer col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
		<p>© Copyright 2021 By Joker Wu All Rights Reserved. </p>
</div>
</footer>

	<!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</body>

</html>
</html>