<!-- Content -->
<script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>

	<div class="container">
		<h3>刪除客戶資料</h3>
		<form id="form" action="" method="post">
		<!-- 廠商編號 -->
<?
	$c_id=$_GET["c_id"];
	$stmt = $db_link->prepare("SELECT * FROM customer WHERE m_num=? and c_num=?");
	$stmt->execute([$m_num,$c_id]);
	$row=$stmt->fetch();
?>
			<div class="form-group form-inline">
				<label for="usereid">客戶名稱：</label>
				<?=$row["c_username"];?>
			</div>
			<div class="form-group form-inline">
				<label for="userpasswd">聯絡人：</label>
				<?=$row["c_pname"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">聯絡人職稱：</label>
				<?=$row["c_title"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">聯絡電話：</label>
				<?=$row["c_tel"];?>
			</div>
			
			<div class="form-group form-inline">
				<label for="username">行動電話：</label>
				<?=$row["c_phone"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">郵遞區號：</label>
				<?=$row["c_pcode"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">住址：</label>
				<?=$row["c_addr"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">E-Mail：</label>
				<?=$row["c_mail"];?>
			</div>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<div><?=$row["c_memo"];?></div>
			</div>
			
          <hr size="1" />
<?
$stmt->close;
if($_POST["action"]=="del"){
	echo "ok";
	$query = 'DELETE FROM customer WHERE m_num=? and c_num=?';
	$stmt2 = $db_link->prepare($query);
	$stmt2->execute([$m_num,$c_id]);
	$stmt2->close;
	//header("Location: index.php?a=member_center");	
	echo "<script> alert('客戶資料刪除完成~');";
	echo "window.location.href='index.php?a=customer_list';</script>";
}
?>
          <p align="center">
            <input name="action" type="hidden" id="action" value="del">
            <input type="submit" name="Submit" value="刪除">
            <input type="button" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		  <!--
			<button type="submit" class="btn btn-default">送出</button>
			<button type="button" class="btn btn-default" onClick="history.back();">回上一頁</button>
		-->
		</form>
	</div>

	