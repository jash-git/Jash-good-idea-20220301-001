<?
session_start();
require_once("db.php");

$m_num = $_SESSION["loginMember"];

if(isset($_POST["action"])&&($_POST["action"]=="add")){

		echo "可以新增";
		try {
			
$data = [$m_num,
		$_POST["p_id"],
		$_POST["pnum"],
		$_POST["pname"],
		$_POST["snumx"],
		$_POST["pcost"],
		$_POST["pprice"],
		$_POST["pstock"],
		$_POST["memo"]
		];
		
		$query_insert = "INSERT INTO product (m_num, p_num, ps_num,p_name, s_num, p_cost, p_price, p_stock, p_memo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		$stmt = $db_link->prepare($query_insert);

		$stmt->execute($data);
		header("Location: index.php?a=product_list");	
		
		}catch (PDOException $ex) {
			error($ex);
		}
}

?>