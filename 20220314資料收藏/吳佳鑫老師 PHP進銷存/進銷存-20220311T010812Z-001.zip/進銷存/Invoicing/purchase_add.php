<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="ckeditor/ckeditor.js"></script>
<!-- Content -->
<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}

    .box {
        position: absolute;
        font-family: "微軟正黑體";
		top: 20vh; 
		left: 10vw;
        text-align: center;
    }
	.box2 {
        position: absolute;
        font-family: "微軟正黑體";
    	top: 20vh; 
		left: 10vw;
        text-align: center;
    }
    .service {
        width: 80vw;
        position: relative;
        background: lightblue;
        cursor: default;
    }
    .service p {

    }
	
	.service2 {
        width: 80vw;
        position: relative;
        background: lightblue;
        cursor: default;
    }
.navFixed {
  z-index: 99;
  top: 5vh;  
  left: -5vw;
  position: fixed;      
}
</style>

	<div class="container">
		<h3>新增進貨單</h3>
		<form id="form" action="pu_insert.php" method="post">
		<!-- 供應商編號 -->
<?
$date = new DateTime('first day of this month');
$pu_id=$date->format('YmdHis');
?>
		<input name="pu_id" type="hidden" value="<?=$pu_id;?>">
			<div class="form-group form-inline">
				<label for="punum">進貨單號：</label>
				<input type="text" name="punum" class="form-control col-sm-3" id="punum" placeholder="輸入進貨單號">
			</div>
<!--商品明細 浮動視窗-->
<nav class="go">
<div class="box2">
    <div class="service2">
        <p id="spselection">
<?
	$stmt = $db_link->prepare("SELECT * FROM  product where m_num=?");//一般使用者
	$stmt->execute([$m_num]);
	$no=$stmt->rowCount();  
	while($row=$stmt->fetch()){
?>
		<a href="#"><span class="t"><?=$row["p_name"];?></span>
		<span class="x" style="display:none;"><?=$row["p_num"];?></span>
		<span class="y" style="display:none;"><?=$row["p_cost"];?></span>
		</a> ||
<?
}
?>
		</p>
    </div>
</div>
</nav>
<!--商品明細 浮動視窗 END-->

<!--供應商 浮動視窗-->
<nav class="go2">
<div class="box">
    <div class="service">
        <p id="ssselection">
<?
	$stmt = $db_link->prepare("SELECT * FROM  supplier where m_num=?");//一般使用者
	$stmt->execute([$m_num]);
	while($row=$stmt->fetch()){
?>
		<a href="#"><span class="t"><?=$row["s_username"];?></span>
		<span class="x" style="display:none;"><?=$row["s_num"];?></span>
		</a> ||
<?
}
?>
		</p>
    </div>
</div>
</nav>
<!--供應商 浮動視窗 END-->
<!-- -->
	<div class="container">
		<div class="row">
			<div class="col">
				<h3>進貨明細</h3> 
				<p style="text-align:right;"><a href="#" class="add_button">新增產品</a></p>	
				<table class="table">
					<thead>
						<tr>
							<th>商品名稱</th>
							<th>供應商</th>
							<th>成本</th>
							<th>數量</th>
						</tr>
					</thead>
					<tbody class="input_fields_wrap">
						<tr>
							<td><input type="text" name="pname[]" class="form-control " id="pname" placeholder="選擇商品名稱">
							<input type="hidden" name="pnum[]" class="form-control " id="pnum">
							</td>
							<td><input type="text" name="sname[]" class="form-control " id="sname" placeholder="選擇供應商"></td>
							<input type="hidden" name="snum[]" class="form-control " id="snum">
							<td><input type="text" name="pcost[]" class="form-control " id="pcost" placeholder="輸入商品成本"></td>
							<td><input type="text" name="puquantity[]"  class="form-control " id="puquantity" placeholder="輸入數量">	
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- -->
<hr>
			<div class="form-group form-inline">
				<label for="username">備註：</label>
				<textarea rows="4" name="memo" class="form-control col-sm-3" id="memo" placeholder="輸入備註"></textarea>
			</div>
<script>
CKEDITOR.replace( 'memo', {});
</script>
			
          <hr size="1" />
          <p align="center">
            <input name="action" type="hidden" id="action" value="add">
            <input type="submit" class="btn btn-outline-secondary" name="Submit" value="送出">
            <input type="reset" class="btn btn-outline-secondary" name="Submit3" value="重設資料">
            <input type="button" class="btn btn-outline-secondary" name="Submit" value="回上一頁" onClick="window.history.back();">
          </p>
		</form>
	</div>

<script>
var x = 0;
var axx = 0;
var axs = 0;
$(document).ready(function() 
 {
	  $(".service").hide();
	  $(".service2").hide();
//
//供應商選擇 START
	$("#sname").click(function () {
	$(".service").fadeToggle();
    axs=0;
	});
	
	$(document).on("click","#sname1",function () {
	 $(".service").fadeToggle();
     axs=1;
	});
	
	$(document).on("click","#sname2",function () {
	 $(".service").fadeToggle();
     axs=2;
	});
	
	$(document).on("click","#sname3",function () {
	 $(".service").fadeToggle();
     axs=3;
	});
	
	$(document).on("click","#sname4",function () {
	 $(".service").fadeToggle();
     axs=4;
	});
	
	$(document).on("click","#sname5",function () {
	 $(".service").fadeToggle();
     axs=5;
	});
	
	$(document).on("click","#sname6",function () {
	 $(".service").fadeToggle();
     axs=6;
	});
	
	$(document).on("click","#sname7",function () {
	 $(".service").fadeToggle();
     axs=7;
	});
	
	$(document).on("click","#sname8",function () {
	 $(".service").fadeToggle();
     axs=8;
	});
	
	$(document).on("click","#sname9",function () {
	 $(".service").fadeToggle();
     axs=9;
	});
	
	$(document).on("click","#sname10",function () {
	 $(".service").fadeToggle();
     axs=10;
	});
//供應商選擇 END
//供應商選擇 點擊給值
	$('#ssselection a').click(function(e) 
    {
	 var xx=$(this).find("span.t").text();//供應商名稱
	 var xxx=$(this).find("span.x").text();//供應商代號
	 
	 if(axs<1)
	 {
	  //初始的欄位
	  $("#sname").val(xx);
	  $("#snum").val(xxx);
	 }
	 else
	 {
	  //動態產生的欄位
	  $("#sname"+x).val(xx);
	  $("#snum"+x).val(xxx);
	 }
    });
//-----供應商選擇 點擊給值 END
//--------------------
//選擇商品名稱 START
	$("#pname").click(function () {
	$(".service2").fadeToggle();
    axx=0;
	});
	
	$(document).on("click","#pname1",function () {
	 $(".service2").fadeToggle();
     axx=1;
	});
	
	$(document).on("click","#pname2",function () {
	 $(".service2").fadeToggle();
     axx=2;
	});
	
	$(document).on("click","#pname3",function () {
	 $(".service2").fadeToggle();
     axx=3;
	});
	
	$(document).on("click","#pname4",function () {
	 $(".service2").fadeToggle();
     axx=4;
	});
	
	$(document).on("click","#pname5",function () {
	 $(".service5").fadeToggle();
     axx=5;
	});
	
	$(document).on("click","#pname6",function () {
	 $(".service2").fadeToggle();
     axx=6;
	});
	
	$(document).on("click","#pname7",function () {
	 $(".service2").fadeToggle();
     axx=7;
	});
	
	$(document).on("click","#pname8",function () {
	 $(".service2").fadeToggle();
     axx=8;
	});
	
	$(document).on("click","#pname9",function () {
	 $(".service2").fadeToggle();
     axx=9;
	});
	
	$(document).on("click","#pname10",function () {
	 $(".service2").fadeToggle();
     axx=10;
	});
//選擇商品名稱 END

//選擇商品名稱 點擊給值
	$('#spselection a').click(function(e) 
    {
	 var xx=$(this).find("span.t").text();//商品名
	 var xxx=$(this).find("span.x").text();//商品代號
	 var xxxx=$(this).find("span.y").text();//成本
	 
	 if(axx<1)
	 {
	  //初始的欄位
	  $("#pname").val(xx);
	  $("#pnum").val(xxx);
	  $("#pcost").val(xxxx);
	 }
	 else
	 {
	  //動態產生的欄位
	  $("#pname"+x).val(xx);
	  $("#pnum"+x).val(xxx);
	  $("#pcost"+x).val(xxxx);
	 }
    });
//-----選擇商品名稱 點擊給值 END
//動態欄位
	var max_fields      = 10; //maximum input boxes allowed
	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
	var add_button      = $(".add_button"); //Add button ID

	$(add_button).on('click',function(e){ //on add input button click
		e.preventDefault();
		if(x < max_fields){ //max input box allowed
			x++; //text box increment
			$(wrapper).append(
			'<tr>'+
			'<td><input type="text" name="pname[]" class="form-control " id="pname'+
			x+
			'" placeholder="選擇商品名稱">'+
			'<input type="hidden" name="pnum[]" class="form-control " id="pnum'+
			x+
			'">'+
			'</td>'+
			'<td><input type="text" name="sname[]" class="form-control " id="sname'+
			x+
			'" placeholder="選擇供應商">'+
			'<input type="hidden" name="snum[]" class="form-control " id="snum'+
			x+
			'">'+
			'</td>'+				
			'<td><input type="text" name="pcost[]" class="form-control " id="pcost'+
			x+
			'" placeholder="輸入商品成本"></td>'+
			'<td><input type="text" name="puquantity[]"  class="form-control " id="puquantity" placeholder="輸入數量">'+		
			'<a href="#" class="remove_field">刪除</a></td>'+
			'</tr>'); //add input box
		}

	});

	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		e.preventDefault(); 
		$(this).closest("tr").remove();
		x--;
	})
	
	$(wrapper).on("click",".Sel_product", function(e){ //user click on remove text
		e.preventDefault(); 
		$(".service2").fadeToggle();
	})
//浮動視窗
	 $(window).scroll(function() {
    if ($(this).scrollTop() > 50)  {          /* 要滑動到選單的距離 */
       $('.go').addClass('navFixed');   /* 幫選單加上固定效果 */
	   //console.log("123");
    } else {
      $('.go').removeClass('navFixed'); /* 移除選單固定效果 */
    }
  });
	//-----
});

</script>