<?
//資料庫 設定 
 $db_host = "localhost"; //路徑
 $db_username = "root"; //帳號
 $db_password = "1234"; //密碼
 $db_name = "invoicing"; 
 //pdo -> mysql連線
 try{
	 $db_link = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8",$db_username,$db_password);
 }catch(PDOException $e){
	 print "資料庫連結失敗...Msg:{$e->getMessage()}<br/>";
	 die();
 }
 //ini_set("display_errors","Off"); //開啟偵錯
?>