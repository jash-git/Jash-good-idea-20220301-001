<?
session_start();
require_once("db.php");

$m_num = $_SESSION["loginMember"];

if(isset($_POST["action"])&&($_POST["action"]=="add")){

		echo "可以新增";
		try {
			
$data = [$m_num,
		$_POST["s_id"],
		$_POST["username"],
		$_POST["pname"],
		$_POST["stitle"],
		$_POST["saddr"],
		$_POST["email"],
		$_POST["pcode"],
		$_POST["stel"],
		$_POST["sphone"],
		$_POST["memo"]
		];
		
		$query_insert = "INSERT INTO supplier (m_num, s_num, s_username, s_pname, s_title, s_addr, s_mail, s_pcode, s_tel, s_phone, s_memo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
		
		$stmt = $db_link->prepare($query_insert);

		$stmt->execute($data);
		header("Location: index.php?a=supplier_list");	
		
		}catch (PDOException $ex) {
			error($ex);
		}
}

?>