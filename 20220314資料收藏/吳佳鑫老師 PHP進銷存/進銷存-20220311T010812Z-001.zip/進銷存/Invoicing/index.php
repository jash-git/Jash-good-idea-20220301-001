<?
session_start();
require_once("db.php");
ini_set("display_errors","Off"); //開啟偵錯

$cmd=$_GET["a"];

//echo $cmd;
$m_num=$_SESSION["loginMember"];
$level=$_SESSION["memberLevel"];

if(!$cmd)
$cmd="000";

include "head.php";
include "breadcrumb.php"; //麵包屑導覽列

switch($cmd)
{
//-----------會員 member
 case "member_add": //會員註冊-申請-新增
 //include "logincheck.php"; //登入檢查
 include "member.php";
 break;
 
 case "member_center": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 if($level==1)
 include "member_center.php";//最高權限
 else
 include "member_centerx.php";//一般層級	 
 break;

 case "member_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "member_re.php";
 break;
 
 case "member_del": //進入後台 (管理者)-刪除
 include "logincheck.php"; //登入檢查
 include "member_del.php";
 break; 
 
 case "member_view": //進入後台 (管理者)-查看
 include "logincheck.php"; //登入檢查
 include "member_view.php";
 break; 
 
 case "member_forget": //會員註冊-忘記密碼
 include "member_forget.php";
 break;

//-----------供應商 supplier
 case "supplier_add": //供應商-新增
 include "logincheck.php"; //登入檢查
 include "supplier_add.php";
 break;
 
 case "supplier_list": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 include "supplier_list.php";
 break;

 case "supplier_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "supplier_re.php";
 break;
 
 case "supplier_del": //進入後台 (管理者)-刪除
 include "supplier_del.php";
 break; 
 
 case "supplier_view": //進入後台 (管理者)-查看
 include "logincheck.php"; //登入檢查
 include "supplier_view.php";
 break; 
 
//-----------客戶 customer
 case "customer_add": //客戶-申請-新增
 include "logincheck.php"; //登入檢查
 include "customer_add.php";
 break;
 
 case "customer_list": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 include "customer_list.php";
 break;

 case "customer_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "customer_re.php";
 break;
 
 case "customer_del": //進入後台 (管理者)-刪除
 include "logincheck.php"; //登入檢查
 include "customer_del.php";
 break; 
 
 case "customer_view": //進入後台 (管理者)-查看
 include "logincheck.php"; //登入檢查
 include "customer_view.php";
 break; 
 //-----------產品 product
 case "product_add": //產品-新增
 include "logincheck.php"; //登入檢查
 include "product_add.php";
 break;
 
 case "product_list": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 include "product_list.php";
 break;

 case "product_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "product_re.php";
 break;
 
 case "product_del": //進入後台 (管理者)-刪除
 include "logincheck.php"; //登入檢查
 include "product_del.php";
 break; 
 
 case "product_view": //進入後台 (管理者)-查看
 include "logincheck.php"; //登入檢查
 include "product_view.php";
 break; 
 
 //-----------進貨作業 purchase
 case "purchase_add": //進貨單-新增
 include "logincheck.php"; //登入檢查
 include "purchase_add.php";
 break;
 
 case "purchase_list": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 include "purchase_list.php";
 break;

 case "purchase_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "purchase_re.php";
 break;
 
 case "purchase_del": //進入後台 (管理者)-刪除
 include "logincheck.php"; //登入檢查
 include "purchase_del.php";
 break; 
 
 case "purchase_view": //進入後台 (管理者)-查看
 //include "purchase_view.php"; //與入庫一樣的功能
 include "logincheck.php"; //登入檢查
 include "purchase_iqc.php";
 break; 
 
 case "purchase_iqc": //進入後台 (管理者)-入庫
 include "logincheck.php"; //登入檢查
 include "purchase_iqc.php";
 break; 
 //-----------銷貨作業 sales
 case "sales_add": //進貨單-新增
 include "logincheck.php"; //登入檢查
 include "sales_add.php";
 break;
 
 case "sales_list": //進入後台 (管理者)
 include "logincheck.php"; //登入檢查
 include "sales_list.php";
 break;

 case "sales_re": //進入後台 (管理者)-修改
 include "logincheck.php"; //登入檢查
 include "sales_re.php";
 break;
 
 case "sales_del": //進入後台 (管理者)-刪除
 include "logincheck.php"; //登入檢查
 include "sales_del.php";
 break; 
 
 case "sales_view": //進入後台 (管理者)-查看 出貨
 include "logincheck.php"; //登入檢查
 include "sales_view.php"; //與出貨一樣的功能
 //include "sales_oqc.php";
 break; 
 
 case "sales_oqc": //進入後台 (管理者)-出貨
 include "logincheck.php"; //登入檢查
 //include "sales_oqc.php";
 include "sales_view.php"; //與出貨一樣的功能
 break; 

 //case "sales_test": //進入後台 (管理者)-出貨
 //include "test2.php";
 //break;  
//-----------



 default:
 include "login.php"; //登入頁
}

include "footer.php";
?>